#!/usr/bin/env python3
"""
Script to run the HealthAI Streamlit frontend
"""

import subprocess
import sys
import os

def install_requirements():
    """Install required packages"""
    print("Installing required packages...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])

def run_frontend():
    """Run the Streamlit frontend"""
    print("Starting HealthAI Streamlit frontend...")
    print("Frontend will be available at: http://localhost:8501")
    print("\nPress Ctrl+C to stop the frontend\n")
    
    try:
        subprocess.run([
            sys.executable, "-m", "streamlit", "run", 
            "frontend/streamlit_app.py",
            "--server.port", "8501",
            "--server.address", "0.0.0.0"
        ])
    except KeyboardInterrupt:
        print("\nFrontend stopped.")

if __name__ == "__main__":
    # Check if requirements.txt exists
    if os.path.exists("requirements.txt"):
        install_requirements()
    
    run_frontend()