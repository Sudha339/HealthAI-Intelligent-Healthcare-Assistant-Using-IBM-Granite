import streamlit as st
import requests
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import json
import time

# Configure Streamlit page
st.set_page_config(
    page_title="HealthAI - Intelligent Healthcare Assistant",
    page_icon="🏥",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #3B82F6, #10B981);
        padding: 1rem;
        border-radius: 10px;
        color: white;
        text-align: center;
        margin-bottom: 2rem;
    }
    
    .feature-card {
        background: white;
        padding: 1.5rem;
        border-radius: 10px;
        border: 1px solid #E5E7EB;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        margin-bottom: 1rem;
    }
    
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1rem;
        border-radius: 10px;
        color: white;
        text-align: center;
    }
    
    .emergency-alert {
        background: #FEE2E2;
        border: 2px solid #EF4444;
        padding: 1rem;
        border-radius: 10px;
        color: #DC2626;
        font-weight: bold;
    }
    
    .success-message {
        background: #D1FAE5;
        border: 2px solid #10B981;
        padding: 1rem;
        border-radius: 10px;
        color: #047857;
    }
    
    .chat-message {
        background: #F3F4F6;
        padding: 1rem;
        border-radius: 10px;
        margin: 0.5rem 0;
    }
    
    .user-message {
        background: #3B82F6;
        color: white;
        text-align: right;
    }
    
    .ai-message {
        background: #10B981;
        color: white;
    }
</style>
""", unsafe_allow_html=True)

# API Configuration
API_BASE_URL = "http://localhost:8000"

def call_api(endpoint, method="GET", data=None):
    """Helper function to call API endpoints"""
    try:
        url = f"{API_BASE_URL}{endpoint}"
        if method == "GET":
            response = requests.get(url)
        elif method == "POST":
            response = requests.post(url, json=data)
        
        if response.status_code == 200:
            return response.json()
        else:
            st.error(f"API Error: {response.status_code}")
            return None
    except requests.exceptions.ConnectionError:
        st.error("⚠️ Cannot connect to HealthAI API. Please ensure the backend server is running on port 8000.")
        return None
    except Exception as e:
        st.error(f"Error calling API: {str(e)}")
        return None

def main():
    # Header
    st.markdown("""
    <div class="main-header">
        <h1>🏥 HealthAI - Intelligent Healthcare Assistant</h1>
        <p>AI-powered healthcare insights, disease prediction, and personalized treatment plans</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Sidebar navigation
    st.sidebar.title("🩺 Navigation")
    page = st.sidebar.selectbox(
        "Choose a feature:",
        ["🏠 Dashboard", "🔍 Symptom Checker", "📋 Treatment Plans", "📊 Health Analytics", "💬 Patient Chat", "🚨 Emergency Helper"]
    )
    
    # Main content based on selected page
    if page == "🏠 Dashboard":
        show_dashboard()
    elif page == "🔍 Symptom Checker":
        show_symptom_checker()
    elif page == "📋 Treatment Plans":
        show_treatment_plans()
    elif page == "📊 Health Analytics":
        show_health_analytics()
    elif page == "💬 Patient Chat":
        show_patient_chat()
    elif page == "🚨 Emergency Helper":
        show_emergency_helper()

def show_dashboard():
    st.header("🏠 Dashboard")
    
    # Quick stats
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown("""
        <div class="metric-card">
            <h3>Health Score</h3>
            <h2>89/100</h2>
            <p>Excellent</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class="metric-card">
            <h3>Consultations</h3>
            <h2>24</h2>
            <p>This month</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown("""
        <div class="metric-card">
            <h3>Response Time</h3>
            <h2>2.3s</h2>
            <p>Average</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        st.markdown("""
        <div class="metric-card">
            <h3>Accuracy</h3>
            <h2>94.2%</h2>
            <p>AI Predictions</p>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("<br>", unsafe_allow_html=True)
    
    # Feature overview
    st.subheader("🚀 Available Features")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        <div class="feature-card">
            <h3>🔍 Symptom Checker</h3>
            <p>AI-powered disease prediction based on your symptoms. Get instant analysis and recommendations.</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
        <div class="feature-card">
            <h3>📋 Treatment Plans</h3>
            <p>Personalized treatment recommendations and step-by-step health guidance plans.</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class="feature-card">
            <h3>📊 Health Analytics</h3>
            <p>Comprehensive insights into your health patterns, trends, and risk factors.</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
        <div class="feature-card">
            <h3>💬 Patient Chat</h3>
            <p>24/7 AI health assistant for immediate medical guidance and support.</p>
        </div>
        """, unsafe_allow_html=True)
    
    # Recent activity
    st.subheader("📈 Recent Health Insights")
    
    # Sample chart
    dates = pd.date_range(start='2024-01-01', end='2024-01-30', freq='D')
    health_scores = [85 + (i % 10) for i in range(len(dates))]
    
    fig = px.line(x=dates, y=health_scores, title="Health Score Trend (Last 30 Days)")
    fig.update_layout(xaxis_title="Date", yaxis_title="Health Score")
    st.plotly_chart(fig, use_container_width=True)

def show_symptom_checker():
    st.header("🔍 AI Symptom Checker")
    st.write("Describe your symptoms and get AI-powered health insights")
    
    # Symptom input
    col1, col2 = st.columns([2, 1])
    
    with col1:
        symptoms_input = st.text_area(
            "Describe your symptoms:",
            placeholder="e.g., headache, fever, cough, sore throat...",
            height=100
        )
        
        # Additional information
        col_a, col_b = st.columns(2)
        with col_a:
            severity = st.slider("Symptom Severity (1-10)", 1, 10, 5)
            age = st.number_input("Age", min_value=1, max_value=120, value=30)
        
        with col_b:
            duration = st.selectbox("Duration", ["Recent (< 24h)", "1-3 days", "1 week", "More than 1 week"])
            gender = st.selectbox("Gender", ["Male", "Female", "Other", "Prefer not to say"])
    
    with col2:
        st.subheader("Common Symptoms")
        common_symptoms = [
            "Fever", "Headache", "Cough", "Sore throat", "Fatigue", 
            "Nausea", "Body aches", "Runny nose", "Chest pain", "Dizziness"
        ]
        
        selected_symptoms = []
        for symptom in common_symptoms:
            if st.checkbox(symptom):
                selected_symptoms.append(symptom)
    
    # Combine manual input and selected symptoms
    all_symptoms = []
    if symptoms_input:
        all_symptoms.extend([s.strip() for s in symptoms_input.split(',')])
    all_symptoms.extend(selected_symptoms)
    
    if st.button("🔍 Analyze Symptoms", type="primary"):
        if all_symptoms:
            with st.spinner("Analyzing your symptoms with AI..."):
                # Call API
                data = {
                    "symptoms": all_symptoms,
                    "severity": severity,
                    "duration": duration,
                    "age": age,
                    "gender": gender
                }
                
                result = call_api("/analyze-symptoms", "POST", data)
                
                if result:
                    # Display results
                    st.success("✅ Analysis Complete!")
                    
                    # Urgency level
                    urgency = result.get("urgency_level", "Unknown")
                    if "Emergency" in urgency:
                        st.markdown(f"""
                        <div class="emergency-alert">
                            🚨 {urgency}
                        </div>
                        """, unsafe_allow_html=True)
                    else:
                        st.info(f"📋 Urgency Level: {urgency}")
                    
                    # Possible conditions
                    st.subheader("🎯 Possible Conditions")
                    conditions = result.get("possible_conditions", [])
                    
                    if conditions:
                        for i, condition in enumerate(conditions[:3]):
                            with st.expander(f"{condition['condition']} - {condition['confidence']:.1f}% match"):
                                st.write(f"**Category:** {condition['category'].title()}")
                                st.write(f"**Severity:** {condition['severity'].title()}")
                                st.write(f"**Estimated Duration:** {condition['duration']}")
                                st.write("**Recommended Treatments:**")
                                for treatment in condition['treatment']:
                                    st.write(f"• {treatment}")
                    else:
                        st.warning("No specific conditions identified. Please consult a healthcare provider.")
                    
                    # Recommendations
                    st.subheader("💡 Recommendations")
                    recommendations = result.get("recommendations", [])
                    for rec in recommendations:
                        st.write(f"• {rec}")
                    
                    # Disclaimer
                    st.markdown("""
                    <div style="background: #FEF3C7; padding: 1rem; border-radius: 10px; border: 1px solid #F59E0B; margin-top: 1rem;">
                        <strong>⚠️ Medical Disclaimer:</strong> This tool provides general health information and should not replace professional medical advice. 
                        Always consult with a healthcare provider for proper diagnosis and treatment.
                    </div>
                    """, unsafe_allow_html=True)
        else:
            st.warning("Please enter at least one symptom to analyze.")

def show_treatment_plans():
    st.header("📋 Treatment Plans")
    st.write("Personalized treatment recommendations and health guidance")
    
    # Get treatment plans from API
    plans_data = call_api("/treatment-plans")
    
    if plans_data:
        plans = plans_data.get("treatment_plans", [])
        
        # Filter options
        col1, col2 = st.columns([3, 1])
        with col1:
            search_term = st.text_input("🔍 Search treatment plans...")
        with col2:
            category_filter = st.selectbox("Category", ["All", "Respiratory", "Mental Health", "Digestive", "Cardiovascular"])
        
        # Display plans
        for plan in plans:
            if category_filter == "All" or plan["category"] == category_filter:
                if not search_term or search_term.lower() in plan["name"].lower():
                    with st.expander(f"📋 {plan['name']} - {plan['duration']} ({plan['difficulty']})"):
                        st.write(f"**Category:** {plan['category']}")
                        st.write(f"**Duration:** {plan['duration']}")
                        st.write(f"**Difficulty:** {plan['difficulty']}")
                        
                        st.subheader("📅 Treatment Steps")
                        for step in plan["steps"]:
                            st.write(f"**Day {step['day']}:** {step['action']}")
                            st.write(f"   ↳ {step['details']}")
                        
                        if plan["medications"]:
                            st.subheader("💊 Medications")
                            for med in plan["medications"]:
                                st.write(f"• {med}")
                        
                        st.subheader("⚠️ Precautions")
                        for precaution in plan["precautions"]:
                            st.write(f"• {precaution}")
                        
                        if st.button(f"Start {plan['name']}", key=f"start_{plan['id']}"):
                            st.success(f"✅ Started treatment plan: {plan['name']}")
    else:
        st.error("Unable to load treatment plans. Please check API connection.")

def show_health_analytics():
    st.header("📊 Health Analytics")
    st.write("Comprehensive insights into your health patterns and trends")
    
    # Get analytics data
    analytics_data = call_api("/health-analytics")
    
    if analytics_data:
        # Health Score
        health_score = analytics_data.get("health_score", 0)
        
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            fig = go.Figure(go.Indicator(
                mode = "gauge+number+delta",
                value = health_score,
                domain = {'x': [0, 1], 'y': [0, 1]},
                title = {'text': "Overall Health Score"},
                delta = {'reference': 80},
                gauge = {
                    'axis': {'range': [None, 100]},
                    'bar': {'color': "darkblue"},
                    'steps': [
                        {'range': [0, 50], 'color': "lightgray"},
                        {'range': [50, 80], 'color': "gray"},
                        {'range': [80, 100], 'color': "lightgreen"}
                    ],
                    'threshold': {
                        'line': {'color': "red", 'width': 4},
                        'thickness': 0.75,
                        'value': 90
                    }
                }
            ))
            fig.update_layout(height=300)
            st.plotly_chart(fig, use_container_width=True)
        
        # Risk Factors
        st.subheader("🎯 Risk Factor Analysis")
        risk_factors = analytics_data.get("risk_factors", [])
        
        if risk_factors:
            factors_df = pd.DataFrame(risk_factors)
            
            fig = px.bar(
                factors_df, 
                x="factor", 
                y="score", 
                color="status",
                title="Health Risk Factors",
                color_discrete_map={
                    "good": "#10B981",
                    "fair": "#F59E0B", 
                    "moderate": "#EF4444",
                    "poor": "#DC2626"
                }
            )
            st.plotly_chart(fig, use_container_width=True)
        
        # Trends
        st.subheader("📈 Health Trends")
        trends = analytics_data.get("trends", {}).get("last_30_days", {})
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Consultations", trends.get("consultations", 0), "2")
        with col2:
            st.metric("Symptoms Reported", trends.get("symptoms_reported", 0), "-3")
        with col3:
            st.metric("Improvement Rate", f"{trends.get('improvement_rate', 0)}%", "5%")
        
        # Recommendations
        st.subheader("💡 Personalized Recommendations")
        recommendations = analytics_data.get("recommendations", [])
        for rec in recommendations:
            st.write(f"• {rec}")
    
    else:
        st.error("Unable to load health analytics. Please check API connection.")

def show_patient_chat():
    st.header("💬 AI Health Assistant")
    st.write("24/7 AI-powered medical guidance and support")
    
    # Initialize chat history
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = [
            {
                "role": "assistant",
                "content": "Hello! I'm your AI health assistant. I'm here to help with medical questions, symptom analysis, and health guidance. How can I assist you today?"
            }
        ]
    
    # Display chat history
    for message in st.session_state.chat_history:
        if message["role"] == "user":
            st.markdown(f"""
            <div class="chat-message user-message">
                <strong>You:</strong> {message["content"]}
            </div>
            """, unsafe_allow_html=True)
        else:
            st.markdown(f"""
            <div class="chat-message ai-message">
                <strong>AI Assistant:</strong> {message["content"]}
            </div>
            """, unsafe_allow_html=True)
    
    # Chat input
    user_input = st.text_input("Type your health question here...", key="chat_input")
    
    col1, col2, col3 = st.columns([1, 1, 4])
    with col1:
        send_button = st.button("Send", type="primary")
    with col2:
        clear_button = st.button("Clear Chat")
    
    # Quick reply buttons
    st.subheader("Quick Questions")
    quick_questions = [
        "I have a headache",
        "I'm feeling stressed",
        "I have a fever",
        "I can't sleep",
        "I have stomach pain",
        "Emergency guidance"
    ]
    
    cols = st.columns(3)
    for i, question in enumerate(quick_questions):
        with cols[i % 3]:
            if st.button(question, key=f"quick_{i}"):
                user_input = question
                send_button = True
    
    # Process user input
    if send_button and user_input:
        # Add user message to history
        st.session_state.chat_history.append({"role": "user", "content": user_input})
        
        # Get AI response
        with st.spinner("AI is thinking..."):
            response_data = call_api("/chat", "POST", {"message": user_input})
            
            if response_data:
                ai_response = response_data.get("response", "Sorry, I couldn't process your request.")
                st.session_state.chat_history.append({"role": "assistant", "content": ai_response})
                st.rerun()
            else:
                st.error("Unable to get AI response. Please try again.")
    
    # Clear chat
    if clear_button:
        st.session_state.chat_history = [
            {
                "role": "assistant", 
                "content": "Hello! I'm your AI health assistant. How can I help you today?"
            }
        ]
        st.rerun()

def show_emergency_helper():
    st.header("🚨 Emergency Medical Helper")
    
    # Emergency alert
    st.markdown("""
    <div class="emergency-alert">
        🚨 FOR LIFE-THREATENING EMERGENCIES, CALL 911 IMMEDIATELY 🚨
    </div>
    """, unsafe_allow_html=True)
    
    # Emergency contacts
    st.subheader("📞 Emergency Contacts")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        <div style="background: #EF4444; color: white; padding: 1rem; border-radius: 10px; text-align: center;">
            <h3>🚨 Emergency</h3>
            <h2>911</h2>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div style="background: #8B5CF6; color: white; padding: 1rem; border-radius: 10px; text-align: center;">
            <h3>☠️ Poison Control</h3>
            <h2>1-800-222-1222</h2>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown("""
        <div style="background: #10B981; color: white; padding: 1rem; border-radius: 10px; text-align: center;">
            <h3>🧠 Mental Health Crisis</h3>
            <h2>988</h2>
        </div>
        """, unsafe_allow_html=True)
    
    # Emergency protocols
    st.subheader("🆘 Emergency Protocols")
    
    emergency_data = call_api("/emergency-guidance")
    
    if emergency_data:
        protocols = emergency_data.get("emergency_protocols", [])
        
        for protocol in protocols:
            with st.expander(f"🚨 {protocol['situation']}"):
                st.write("**Immediate Steps:**")
                for i, step in enumerate(protocol['steps'], 1):
                    st.write(f"{i}. {step}")
    
    # FAST stroke test
    st.subheader("🧠 FAST Stroke Test")
    st.write("Use this test to quickly identify signs of stroke:")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown("""
        <div style="background: #3B82F6; color: white; padding: 1rem; border-radius: 10px;">
            <h4>F - Face</h4>
            <p>Ask person to smile. Does one side droop?</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div style="background: #10B981; color: white; padding: 1rem; border-radius: 10px;">
            <h4>A - Arms</h4>
            <p>Ask them to raise both arms. Does one drift down?</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown("""
        <div style="background: #8B5CF6; color: white; padding: 1rem; border-radius: 10px;">
            <h4>S - Speech</h4>
            <p>Ask them to repeat a phrase. Is it slurred?</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        st.markdown("""
        <div style="background: #EF4444; color: white; padding: 1rem; border-radius: 10px;">
            <h4>T - Time</h4>
            <p>If any signs present, call 911 immediately!</p>
        </div>
        """, unsafe_allow_html=True)
    
    # Warning signs
    st.subheader("⚠️ General Warning Signs - Call 911 Immediately")
    warning_signs = [
        "Sudden severe headache",
        "Sudden vision changes", 
        "Sudden speech difficulties",
        "Sudden weakness or numbness",
        "Severe chest pain",
        "Difficulty breathing",
        "Severe bleeding",
        "Loss of consciousness",
        "Severe allergic reaction"
    ]
    
    cols = st.columns(3)
    for i, sign in enumerate(warning_signs):
        with cols[i % 3]:
            st.write(f"🚨 {sign}")

if __name__ == "__main__":
    main()