# HealthAI - Intelligent Healthcare Assistant

A comprehensive AI-powered healthcare application built with FastAPI backend and Streamlit frontend, featuring disease prediction, treatment plans, health analytics, and 24/7 patient chat support.

## 🚀 Features

### Core Functionalities
- **🔍 AI Symptom Checker**: Disease prediction based on symptoms using free AI models
- **📋 Treatment Plans**: Personalized treatment recommendations and step-by-step guidance
- **📊 Health Analytics**: Comprehensive health insights, trends, and risk factor analysis
- **💬 Patient Chat**: 24/7 AI health assistant for immediate medical guidance
- **🚨 Emergency Helper**: Rapid assessment and life-saving emergency protocols

### Additional Features
- **🎯 Health Scoring**: AI-powered overall health assessment
- **📈 Trend Analysis**: Health pattern tracking and visualization
- **⚠️ Risk Assessment**: Personalized risk factor identification
- **🏥 Emergency Protocols**: FAST stroke test and emergency guidance
- **📱 Responsive Design**: Works on all devices

## 🛠️ Technology Stack

### Backend (FastAPI)
- **FastAPI**: Modern, fast web framework for building APIs
- **Transformers**: Hugging Face transformers for AI model integration
- **PyTorch**: Deep learning framework
- **Scikit-learn**: Machine learning utilities
- **Pandas & NumPy**: Data processing and analysis

### Frontend (Streamlit)
- **Streamlit**: Interactive web application framework
- **Plotly**: Interactive data visualization
- **Requests**: API communication

### AI Models (Free)
- **Microsoft DialoGPT**: Conversational AI for patient chat
- **Cardiff NLP RoBERTa**: Sentiment analysis for mental health assessment
- **Custom Medical Knowledge Base**: Symptom-disease mapping

## 📦 Installation & Setup

### Prerequisites
- Python 3.8 or higher
- pip package manager

### Quick Start

1. **Clone or download the project files**

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Start the Backend Server**:
   ```bash
   python run_backend.py
   ```
   The API will be available at: http://localhost:8000
   API documentation: http://localhost:8000/docs

4. **Start the Frontend (in a new terminal)**:
   ```bash
   python run_frontend.py
   ```
   The web application will be available at: http://localhost:8501

## 🔧 Usage

### Symptom Checker
1. Navigate to the "🔍 Symptom Checker" page
2. Enter your symptoms or select from common symptoms
3. Provide additional information (age, severity, duration)
4. Click "Analyze Symptoms" for AI-powered analysis
5. Review possible conditions, urgency level, and recommendations

### Treatment Plans
1. Go to "📋 Treatment Plans"
2. Browse available treatment plans by category
3. View detailed step-by-step treatment protocols
4. Start a treatment plan for guided recovery

### Health Analytics
1. Visit "📊 Health Analytics"
2. View your overall health score and trends
3. Analyze risk factors and health patterns
4. Get personalized health recommendations

### Patient Chat
1. Access "💬 Patient Chat"
2. Ask health-related questions in natural language
3. Get instant AI-powered medical guidance
4. Use quick reply buttons for common concerns

### Emergency Helper
1. Go to "🚨 Emergency Helper"
2. Access emergency contact information
3. Follow emergency protocols for various situations
4. Use the FAST stroke test for rapid assessment

## 🏥 Medical Disclaimer

**IMPORTANT**: This application provides general health information and should not replace professional medical advice, diagnosis, or treatment. Always consult with qualified healthcare providers for medical concerns.

**For emergencies, always call 911 immediately.**

## 🔒 Privacy & Security

- No personal health data is stored permanently
- All AI processing happens locally or through secure APIs
- Session data is cleared when the application is closed
- No data is shared with third parties

## 🚀 Deployment Options

### Local Development
- Use the provided run scripts for local testing

### Production Deployment
- **Backend**: Deploy FastAPI with Gunicorn/Uvicorn on cloud platforms
- **Frontend**: Deploy Streamlit on Streamlit Cloud, Heroku, or AWS
- **Docker**: Containerize both services for easy deployment

### Environment Variables
For production, set these environment variables:
```bash
FASTAPI_HOST=0.0.0.0
FASTAPI_PORT=8000
STREAMLIT_HOST=0.0.0.0
STREAMLIT_PORT=8501
```

## 📊 API Endpoints

### Core Endpoints
- `GET /`: Health check
- `POST /analyze-symptoms`: Symptom analysis
- `POST /chat`: AI chat interaction
- `GET /treatment-plans`: Get treatment plans
- `GET /health-analytics`: Health analytics data
- `GET /emergency-guidance`: Emergency protocols

### API Documentation
Visit http://localhost:8000/docs for interactive API documentation.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📝 License

This project is open source and available under the MIT License.

## 🆘 Support

For technical support or medical emergencies:
- **Technical Issues**: Check the console logs and API connectivity
- **Medical Emergencies**: Call 911 immediately
- **Mental Health Crisis**: Call 988 (Suicide & Crisis Lifeline)

## 🔮 Future Enhancements

- Integration with wearable devices
- Telemedicine video consultations
- Prescription management
- Health record integration
- Multi-language support
- Advanced AI model integration

---

**Built with ❤️ for better healthcare accessibility**