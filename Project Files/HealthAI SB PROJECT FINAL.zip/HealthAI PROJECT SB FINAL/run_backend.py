#!/usr/bin/env python3
"""
Script to run the HealthAI FastAPI backend server
Enhanced with better error handling for WebContainer environment
"""

import sys
import os

def check_python_environment():
    """Check if Python environment is properly set up"""
    try:
        import subprocess
        import signal
        return True, None
    except ImportError as e:
        return False, str(e)

def install_requirements():
    """Install required packages using alternative methods"""
    print("Installing required packages...")
    try:
        # Try using os.system as fallback if subprocess fails
        result = os.system(f"{sys.executable} -m pip install -r requirements.txt")
        if result != 0:
            print("Warning: Some packages may not have installed correctly")
        else:
            print("Requirements installed successfully")
    except Exception as e:
        print(f"Error installing requirements: {e}")
        print("Please try installing manually: pip install -r requirements.txt")

def run_backend_alternative():
    """Run backend using alternative method when subprocess is unavailable"""
    print("Starting HealthAI FastAPI backend server...")
    print("Server will be available at: http://localhost:8000")
    print("API documentation will be available at: http://localhost:8000/docs")
    print("\nUsing alternative startup method due to environment constraints...")
    
    try:
        # Use os.system as fallback
        cmd = f"{sys.executable} -m uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload"
        print(f"Running: {cmd}")
        os.system(cmd)
    except Exception as e:
        print(f"Error starting server: {e}")
        print("\nTry running manually:")
        print("python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload")

def run_backend_normal():
    """Run backend using normal subprocess method"""
    import subprocess
    
    print("Starting HealthAI FastAPI backend server...")
    print("Server will be available at: http://localhost:8000")
    print("API documentation will be available at: http://localhost:8000/docs")
    print("\nPress Ctrl+C to stop the server\n")
    
    try:
        subprocess.run([
            sys.executable, "-m", "uvicorn", 
            "backend.main:app", 
            "--host", "0.0.0.0", 
            "--port", "8000", 
            "--reload"
        ])
    except KeyboardInterrupt:
        print("\nServer stopped.")
    except Exception as e:
        print(f"Error running server: {e}")

def main():
    """Main function with environment detection"""
    print("HealthAI Backend Server Launcher")
    print("=" * 40)
    
    # Check Python environment
    env_ok, error_msg = check_python_environment()
    
    if not env_ok:
        print(f"Python environment issue detected: {error_msg}")
        print("Using alternative startup method...")
        
        # Install requirements using alternative method
        if os.path.exists("requirements.txt"):
            install_requirements()
        
        # Run backend using alternative method
        run_backend_alternative()
    else:
        print("Python environment OK")
        
        # Install requirements normally
        if os.path.exists("requirements.txt"):
            import subprocess
            print("Installing required packages...")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
            except Exception as e:
                print(f"Warning: Error installing requirements: {e}")
        
        # Run backend normally
        run_backend_normal()

if __name__ == "__main__":
    main()