from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Optional
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json
import re
from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification
import torch
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import asyncio

app = FastAPI(title="HealthAI API", description="Intelligent Healthcare Assistant API", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize AI models
try:
    # Use a free medical text classification model
    medical_classifier = pipeline(
        "text-classification",
        model="microsoft/DialoGPT-medium",
        tokenizer="microsoft/DialoGPT-medium"
    )
    
    # Sentiment analysis for mental health assessment
    sentiment_analyzer = pipeline("sentiment-analysis", model="cardiffnlp/twitter-roberta-base-sentiment-latest")
    
    print("AI models loaded successfully!")
except Exception as e:
    print(f"Error loading models: {e}")
    medical_classifier = None
    sentiment_analyzer = None

# Data models
class SymptomInput(BaseModel):
    symptoms: List[str]
    severity: Optional[int] = 5
    duration: Optional[str] = "recent"
    age: Optional[int] = 30
    gender: Optional[str] = "unknown"

class ChatMessage(BaseModel):
    message: str
    user_id: Optional[str] = "anonymous"

class HealthMetrics(BaseModel):
    user_id: str
    weight: Optional[float] = None
    height: Optional[float] = None
    blood_pressure: Optional[str] = None
    heart_rate: Optional[int] = None

# Medical knowledge base
MEDICAL_CONDITIONS = {
    "respiratory": {
        "common_cold": {
            "symptoms": ["runny nose", "cough", "sore throat", "sneezing", "fatigue"],
            "severity": "mild",
            "treatment": ["rest", "fluids", "pain relievers", "throat lozenges"],
            "duration": "7-10 days"
        },
        "flu": {
            "symptoms": ["fever", "body aches", "fatigue", "cough", "headache"],
            "severity": "moderate",
            "treatment": ["rest", "antiviral medication", "fluids", "fever reducers"],
            "duration": "1-2 weeks"
        },
        "pneumonia": {
            "symptoms": ["chest pain", "difficulty breathing", "fever", "cough with phlegm"],
            "severity": "severe",
            "treatment": ["antibiotics", "hospitalization", "oxygen therapy"],
            "duration": "2-3 weeks"
        }
    },
    "digestive": {
        "gastroenteritis": {
            "symptoms": ["nausea", "vomiting", "diarrhea", "stomach pain", "fever"],
            "severity": "moderate",
            "treatment": ["hydration", "rest", "bland diet", "electrolytes"],
            "duration": "3-7 days"
        },
        "acid_reflux": {
            "symptoms": ["heartburn", "chest pain", "difficulty swallowing", "regurgitation"],
            "severity": "mild",
            "treatment": ["antacids", "dietary changes", "lifestyle modifications"],
            "duration": "ongoing management"
        }
    },
    "neurological": {
        "migraine": {
            "symptoms": ["severe headache", "nausea", "light sensitivity", "visual disturbances"],
            "severity": "moderate",
            "treatment": ["pain medication", "rest", "dark room", "hydration"],
            "duration": "4-72 hours"
        },
        "tension_headache": {
            "symptoms": ["mild headache", "neck tension", "stress", "fatigue"],
            "severity": "mild",
            "treatment": ["pain relievers", "stress management", "rest"],
            "duration": "30 minutes - 7 days"
        }
    }
}

TREATMENT_PLANS = [
    {
        "id": 1,
        "name": "Common Cold Recovery Plan",
        "category": "Respiratory",
        "duration": "7-10 days",
        "difficulty": "Easy",
        "steps": [
            {"day": 1, "action": "Rest and increase fluid intake", "details": "Drink 8-10 glasses of water, herbal teas"},
            {"day": 2, "action": "Start symptom management", "details": "Use throat lozenges, saline nasal spray"},
            {"day": 3, "action": "Monitor symptoms", "details": "Track fever, assess breathing"},
            {"day": 5, "action": "Gradual activity increase", "details": "Light activities if feeling better"},
            {"day": 7, "action": "Full recovery assessment", "details": "Evaluate if medical attention needed"}
        ],
        "medications": ["Acetaminophen", "Decongestants", "Throat lozenges"],
        "precautions": ["Avoid smoking", "Get plenty of sleep", "Wash hands frequently"]
    },
    {
        "id": 2,
        "name": "Stress Management Program",
        "category": "Mental Health",
        "duration": "21 days",
        "difficulty": "Moderate",
        "steps": [
            {"day": 1, "action": "Establish baseline", "details": "Assess current stress levels and triggers"},
            {"day": 3, "action": "Begin mindfulness practice", "details": "10 minutes daily meditation"},
            {"day": 7, "action": "Implement exercise routine", "details": "30 minutes moderate activity"},
            {"day": 14, "action": "Sleep hygiene optimization", "details": "Consistent sleep schedule"},
            {"day": 21, "action": "Progress evaluation", "details": "Assess improvements and plan continuation"}
        ],
        "medications": [],
        "precautions": ["Limit caffeine", "Avoid alcohol", "Maintain social connections"]
    }
]

def analyze_symptoms_with_ai(symptoms: List[str]) -> Dict:
    """Analyze symptoms using AI and medical knowledge base"""
    symptom_text = " ".join(symptoms).lower()
    
    # Simple keyword matching with medical conditions
    matches = []
    for category, conditions in MEDICAL_CONDITIONS.items():
        for condition_name, condition_data in conditions.items():
            condition_symptoms = condition_data["symptoms"]
            
            # Calculate similarity score
            common_symptoms = sum(1 for s in condition_symptoms if any(cs in symptom_text for cs in s.split()))
            if common_symptoms > 0:
                confidence = (common_symptoms / len(condition_symptoms)) * 100
                matches.append({
                    "condition": condition_name.replace("_", " ").title(),
                    "category": category,
                    "confidence": min(confidence, 95),  # Cap at 95%
                    "severity": condition_data["severity"],
                    "treatment": condition_data["treatment"],
                    "duration": condition_data["duration"]
                })
    
    # Sort by confidence
    matches.sort(key=lambda x: x["confidence"], reverse=True)
    
    return {
        "possible_conditions": matches[:3],  # Top 3 matches
        "urgency_level": determine_urgency(symptoms),
        "recommendations": generate_recommendations(symptoms, matches)
    }

def determine_urgency(symptoms: List[str]) -> str:
    """Determine urgency level based on symptoms"""
    emergency_keywords = ["chest pain", "difficulty breathing", "severe bleeding", "unconscious", "stroke"]
    urgent_keywords = ["high fever", "severe pain", "persistent vomiting", "severe headache"]
    
    symptom_text = " ".join(symptoms).lower()
    
    if any(keyword in symptom_text for keyword in emergency_keywords):
        return "Emergency - Call 911"
    elif any(keyword in symptom_text for keyword in urgent_keywords):
        return "Urgent - Seek immediate care"
    else:
        return "Non-urgent - Monitor symptoms"

def generate_recommendations(symptoms: List[str], matches: List[Dict]) -> List[str]:
    """Generate personalized recommendations"""
    recommendations = [
        "Monitor your symptoms closely",
        "Stay hydrated and get adequate rest",
        "Take your temperature regularly"
    ]
    
    if matches:
        top_match = matches[0]
        recommendations.extend([
            f"Consider treatments for {top_match['condition']}",
            "Consult with a healthcare provider if symptoms worsen"
        ])
    
    return recommendations

def generate_ai_chat_response(message: str) -> str:
    """Generate AI chat response for patient queries"""
    message_lower = message.lower()
    
    # Health-related responses
    if any(word in message_lower for word in ["pain", "hurt", "ache"]):
        return """I understand you're experiencing pain. Here's what I recommend:

1. **Assess the pain**: Rate it on a scale of 1-10
2. **Location**: Note exactly where it hurts
3. **Duration**: How long have you had this pain?
4. **Triggers**: What makes it better or worse?

For immediate relief:
- Apply ice or heat (whichever feels better)
- Try over-the-counter pain relievers if appropriate
- Rest the affected area

⚠️ **Seek immediate medical attention if**:
- Pain is severe (8/10 or higher)
- You have chest pain
- Pain is accompanied by fever, swelling, or numbness

Would you like me to help you assess your specific type of pain?"""

    elif any(word in message_lower for word in ["fever", "temperature", "hot"]):
        return """Fever can be concerning. Here's what you should know:

**Normal body temperature**: 98.6°F (37°C)
**Low-grade fever**: 100.4°F (38°C)
**High fever**: 103°F (39.4°C) or higher

**Immediate care**:
- Take your temperature every 2-4 hours
- Stay hydrated with water, clear broths, or electrolyte solutions
- Rest in a cool, comfortable environment
- Use fever-reducing medication if needed (acetaminophen or ibuprofen)

**Seek medical attention if**:
- Temperature exceeds 103°F (39.4°C)
- Fever lasts more than 3 days
- You have difficulty breathing, chest pain, or severe headache
- You're dehydrated or can't keep fluids down

How high is your fever, and how long have you had it?"""

    elif any(word in message_lower for word in ["cough", "throat", "breathing"]):
        return """Respiratory symptoms need careful attention. Let me help:

**For cough**:
- Stay hydrated to thin mucus
- Use honey (for adults) to soothe throat
- Try steam inhalation
- Avoid irritants like smoke

**For sore throat**:
- Gargle with warm salt water
- Use throat lozenges
- Drink warm liquids
- Rest your voice

**For breathing issues**:
⚠️ **Seek immediate care if you have**:
- Severe difficulty breathing
- Chest pain
- Blue lips or fingernails
- Cannot speak in full sentences

**Monitor for improvement**:
- Most viral respiratory infections improve in 7-10 days
- If symptoms worsen or persist beyond 10 days, see a doctor

Are you experiencing any difficulty breathing or chest pain?"""

    elif any(word in message_lower for word in ["stomach", "nausea", "vomit", "diarrhea"]):
        return """Digestive issues can be uncomfortable. Here's how to manage:

**For nausea/vomiting**:
- Sip clear fluids slowly (water, ginger tea, clear broths)
- Try the BRAT diet: Bananas, Rice, Applesauce, Toast
- Avoid dairy, fatty, or spicy foods
- Rest and avoid strong odors

**For diarrhea**:
- Stay hydrated with electrolyte solutions
- Eat bland, binding foods
- Avoid caffeine, alcohol, and high-fiber foods
- Take probiotics to restore gut health

**Seek medical attention if**:
- Severe dehydration (dizziness, dry mouth, little/no urination)
- Blood in vomit or stool
- High fever with digestive symptoms
- Symptoms persist more than 3 days

How long have you been experiencing these symptoms?"""

    elif any(word in message_lower for word in ["stress", "anxiety", "worried", "mental"]):
        return """Mental health is just as important as physical health. I'm here to help:

**Immediate stress relief techniques**:
- **Deep breathing**: 4 counts in, hold for 4, exhale for 6
- **Grounding exercise**: Name 5 things you see, 4 you hear, 3 you touch, 2 you smell, 1 you taste
- **Progressive muscle relaxation**: Tense and release muscle groups

**Daily stress management**:
- Regular exercise (even 10-minute walks help)
- Consistent sleep schedule (7-9 hours)
- Limit caffeine and alcohol
- Practice mindfulness or meditation
- Stay connected with supportive people

**When to seek professional help**:
- Persistent feelings of sadness or hopelessness
- Difficulty functioning in daily life
- Thoughts of self-harm
- Panic attacks or severe anxiety

**Crisis resources**:
- National Suicide Prevention Lifeline: 988
- Crisis Text Line: Text HOME to 741741

Remember, seeking help is a sign of strength. Would you like specific techniques for managing anxiety or stress?"""

    elif any(word in message_lower for word in ["emergency", "urgent", "911"]):
        return """🚨 **EMERGENCY SITUATIONS - CALL 911 IMMEDIATELY**:

- Chest pain or pressure
- Difficulty breathing or shortness of breath
- Severe bleeding that won't stop
- Loss of consciousness
- Severe allergic reaction
- Signs of stroke (FAST test):
  - **F**ace drooping
  - **A**rm weakness
  - **S**peech difficulty
  - **T**ime to call 911
- Severe burns
- Suspected poisoning
- Severe head injury

**For non-life-threatening urgent care**:
- High fever (103°F+)
- Persistent vomiting
- Severe pain
- Suspected fractures
- Deep cuts needing stitches

**Remember**: When in doubt, it's always better to seek immediate medical attention. Your safety is the top priority.

Are you currently experiencing a medical emergency?"""

    else:
        return """Hello! I'm your AI health assistant. I'm here to help with:

🩺 **Symptom assessment and guidance**
💊 **General health information**
🏥 **When to seek medical care**
🧠 **Mental health support**
🚨 **Emergency guidance**

**Important**: I provide general health information and guidance, but I cannot:
- Diagnose medical conditions
- Prescribe medications
- Replace professional medical care

**For emergencies, always call 911 immediately.**

How can I help you with your health concerns today? Please describe your symptoms or ask any health-related questions."""

@app.get("/")
async def root():
    return {"message": "HealthAI API is running!", "version": "1.0.0"}

@app.post("/analyze-symptoms")
async def analyze_symptoms(symptom_input: SymptomInput):
    """Analyze symptoms and provide AI-powered health insights"""
    try:
        if not symptom_input.symptoms:
            raise HTTPException(status_code=400, detail="No symptoms provided")
        
        # Analyze symptoms
        analysis = analyze_symptoms_with_ai(symptom_input.symptoms)
        
        # Add additional context
        analysis["input_data"] = {
            "symptoms": symptom_input.symptoms,
            "severity": symptom_input.severity,
            "duration": symptom_input.duration,
            "age": symptom_input.age,
            "gender": symptom_input.gender
        }
        
        analysis["timestamp"] = datetime.now().isoformat()
        
        return analysis
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error analyzing symptoms: {str(e)}")

@app.post("/chat")
async def chat_with_ai(chat_message: ChatMessage):
    """Chat with AI health assistant"""
    try:
        response = generate_ai_chat_response(chat_message.message)
        
        return {
            "response": response,
            "timestamp": datetime.now().isoformat(),
            "user_message": chat_message.message
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing chat: {str(e)}")

@app.get("/treatment-plans")
async def get_treatment_plans():
    """Get available treatment plans"""
    return {"treatment_plans": TREATMENT_PLANS}

@app.get("/treatment-plans/{plan_id}")
async def get_treatment_plan(plan_id: int):
    """Get specific treatment plan"""
    plan = next((p for p in TREATMENT_PLANS if p["id"] == plan_id), None)
    if not plan:
        raise HTTPException(status_code=404, detail="Treatment plan not found")
    return plan

@app.get("/health-analytics")
async def get_health_analytics():
    """Generate health analytics and insights"""
    # Generate sample analytics data
    analytics = {
        "health_score": np.random.randint(75, 95),
        "risk_factors": [
            {"factor": "Stress Level", "score": np.random.randint(30, 70), "status": "moderate"},
            {"factor": "Sleep Quality", "score": np.random.randint(60, 90), "status": "good"},
            {"factor": "Exercise Frequency", "score": np.random.randint(40, 80), "status": "fair"},
            {"factor": "Nutrition", "score": np.random.randint(50, 85), "status": "good"}
        ],
        "trends": {
            "last_30_days": {
                "consultations": np.random.randint(5, 15),
                "symptoms_reported": np.random.randint(10, 25),
                "improvement_rate": np.random.randint(70, 95)
            }
        },
        "recommendations": [
            "Maintain regular exercise routine",
            "Focus on stress management techniques",
            "Ensure adequate sleep (7-9 hours)",
            "Stay hydrated throughout the day"
        ],
        "timestamp": datetime.now().isoformat()
    }
    
    return analytics

@app.post("/health-metrics")
async def update_health_metrics(metrics: HealthMetrics):
    """Update user health metrics"""
    # In a real application, this would save to a database
    return {
        "message": "Health metrics updated successfully",
        "metrics": metrics.dict(),
        "timestamp": datetime.now().isoformat()
    }

@app.get("/emergency-guidance")
async def get_emergency_guidance():
    """Get emergency guidance and protocols"""
    return {
        "emergency_contacts": {
            "emergency": "911",
            "poison_control": "1-800-222-1222",
            "mental_health_crisis": "988"
        },
        "emergency_protocols": [
            {
                "situation": "Chest Pain",
                "steps": [
                    "Call 911 immediately",
                    "Have person sit down and rest",
                    "Loosen tight clothing",
                    "If prescribed, help with nitroglycerin",
                    "Monitor breathing and pulse"
                ]
            },
            {
                "situation": "Severe Bleeding",
                "steps": [
                    "Call 911 immediately",
                    "Apply direct pressure to wound",
                    "Elevate injured area if possible",
                    "Do not remove objects from wound",
                    "Treat for shock"
                ]
            },
            {
                "situation": "Difficulty Breathing",
                "steps": [
                    "Call 911 immediately",
                    "Help person sit upright",
                    "Loosen tight clothing",
                    "If available, help with inhaler",
                    "Stay calm and reassure"
                ]
            }
        ]
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)