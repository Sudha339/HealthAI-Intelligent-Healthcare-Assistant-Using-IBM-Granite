# main.py
import os
import sys
from ai_assistant import HealthAIAssistant

def clear_screen():
    """
    Clears the console screen for better readability across different operating systems.
    """
    os.system('cls' if os.name == 'nt' else 'clear')

def main():
    """
    The main function to run the HealthAI Intelligent Healthcare Assistant.
    Handles user interaction, menu navigation, and calls to the AI assistant.
    """
    clear_screen()
    print("*************************************************************")
    print("           Welcome to HealthAI: Intelligent Healthcare Assistant")
    print("*************************************************************")
    print("\nIMPORTANT DISCLAIMER:")
    print("--------------------")
    print("This assistant provides AI-powered information and general suggestions ONLY.")
    print("It is NOT a substitute for professional medical advice, diagnosis, or treatment.")
    print("ALWAYS consult a qualified healthcare provider for any health concerns or before making any decisions related to your health.")
    print("-------------------------------------------------------------\n")

    # Prompt user for their Google Gemini API key
    api_key = input("Please enter your Google Gemini API Key (e.g., AIzaSy...): ")
    if not api_key:
        print("API Key cannot be empty. Exiting. Please restart the app and provide a key.")
        sys.exit(1) # Exit the program if no API key is provided

    try:
        assistant = HealthAIAssistant(api_key)
    except ValueError as e:
        print(f"Error initializing assistant: {e}")
        sys.exit(1) # Exit if the API key is invalid

    chat_history = [] # Initialize chat history for the Patient Chat Assistant feature

    while True:
        print("\n--- HealthAI Main Menu ---")
        print("1. Patient Chat Assistant (AI-powered, non-diagnostic Q&A)")
        print("2. Disease Prediction (Input symptoms, get possible conditions)")
        print("3. Personalized Treatment Plan (Home remedies & general guidelines)")
        print("4. Exit Application")
        print("--------------------------")

        choice = input("Enter your choice (1-4): ")

        if choice == '1':
            clear_screen()
            print("\n--- Patient Chat Assistant ---")
            print("Type 'back' to return to the main menu at any time.")
            print("Type 'clear' to reset the chat history.")
            while True:
                user_message = input("You: ")
                if user_message.lower() == 'back':
                    clear_screen()
                    break # Exit chat mode
                elif user_message.lower() == 'clear':
                    chat_history = [] # Reset history
                    print("Chat history cleared.")
                    continue
                elif not user_message.strip():
                    print("Please enter a message.")
                    continue

                response, chat_history = assistant.chat_with_assistant(user_message, chat_history)
                print(f"HealthAI: {response}")

        elif choice == '2':
            clear_screen()
            print("\n--- Disease Prediction ---")
            print("This feature provides *possible* conditions based on symptoms. It is NOT a diagnosis.")
            symptoms = input("Enter your symptoms, separated by commas (e.g., fever, cough, fatigue): ")
            if not symptoms.strip():
                print("Symptoms cannot be empty. Please provide some symptoms.")
                input("Press Enter to continue...")
                clear_screen()
                continue

            print("\nHealthAI is processing your symptoms...")
            prediction = assistant.predict_disease(symptoms)
            print("\n--- Possible Conditions (Non-Diagnostic) ---")
            print(prediction)
            input("\nPress Enter to continue...") # Pause for user to read before clearing
            clear_screen()

        elif choice == '3':
            clear_screen()
            print("\n--- Personalized Treatment Plan ---")
            print("This feature suggests general home remedies and non-prescriptive guidelines ONLY.")
            print("Always consult a medical professional for treatment and medication advice.")

            symptoms = input("Enter your current symptoms (e.g., sore throat, headache, body aches): ")
            if not symptoms.strip():
                print("Symptoms cannot be empty. Please provide some symptoms.")
                input("Press Enter to continue...")
                clear_screen()
                continue
            
            # Gather user profile information for personalized context
            age = input("Enter your age (e.g., 30): ")
            gender = input("Enter your gender (e.g., male, female, prefer not to say): ")
            medical_history = input("Enter your brief medical history (e.g., 'diabetic', 'no known conditions', 'high blood pressure') or leave blank if none: ")

            print("\nHealthAI is generating your personalized suggestions...")
            plan = assistant.get_treatment_plan(symptoms, age, gender, medical_history)
            print("\n--- Personalized Suggestions (Non-Prescriptive) ---")
            print(plan)
            input("\nPress Enter to continue...") # Pause for user to read
            clear_screen()

        elif choice == '4':
            print("Thank you for using HealthAI. Stay healthy!")
            break # Exit the main application loop

        else:
            print("Invalid choice. Please enter a number between 1 and 4.")
            input("\nPress Enter to continue...")
            clear_screen()

if __name__ == "__main__":
    main()

