# ai_assistant.py
import google.generativeai as genai
import os

class HealthAIAssistant:
    """
    A class to encapsulate the AI functionalities for the HealthAI assistant,
    utilizing the Google Gemini API.
    """

    def __init__(self, api_key):
        """
        Initializes the HealthAIAssistant with the provided Google Gemini API key.
        Configures the generative AI model.

        Args:
            api_key (str): Your Google Gemini API key.
        """
        if not api_key:
            raise ValueError("API Key cannot be empty. Please provide a valid key.")
        genai.configure(api_key=api_key)
        # Updated to use gemini-2.0-flash for general text generation tasks
        self.model = genai.GenerativeModel('gemini-2.0-flash')
        print("HealthAI Assistant initialized. Model 'gemini-2.0-flash' loaded.")

    def chat_with_assistant(self, message, chat_history=None):
        """
        Engages in a conversational chat with the AI assistant.
        Maintains chat history for continuity. Responses are non-diagnostic.

        Args:
            message (str): The user's current message.
            chat_history (list, optional): A list of previous chat turns (user/model).
                                          Defaults to an empty list if not provided.

        Returns:
            tuple: A tuple containing:
                - str: The AI's response.
                - list: The updated chat history.
        """
        # Ensure chat_history is initialized if not provided
        if chat_history is None:
            chat_history = []
        
        # Add the user's message to the chat history for context
        chat_history.append({'role': 'user', 'parts': [message]})
        
        try:
            # Generate content using the conversation history
            # The model will use previous turns to inform its current response
            response = self.model.generate_content(chat_history)
            
            # Check if the response contains valid content
            if response.candidates and response.candidates[0].content and response.candidates[0].content.parts:
                assistant_reply = response.candidates[0].content.parts[0].text
                # Add the model's reply to the history for future turns
                chat_history.append({'role': 'model', 'parts': [assistant_reply]})
                return assistant_reply, chat_history
            else:
                # Handle cases where the model might not return content
                return "I couldn't generate a response. Please try again.", chat_history
        except Exception as e:
            # Catch any exceptions during API call (e.g., network issues, invalid key)
            return f"An error occurred during chat: {e}. Please check your API key and internet connection.", chat_history

    def predict_disease(self, symptoms):
        """
        Suggests possible (non-diagnostic) conditions based on a list of symptoms.
        Emphasizes that it is not a diagnosis.

        Args:
            symptoms (str): A comma-separated string of symptoms (e.g., "fever, cough, fatigue").

        Returns:
            str: A list of possible conditions and brief notes, with a strong disclaimer.
        """
        # Craft a prompt that guides the AI to provide non-diagnostic, suggestive responses
        prompt = (f"Based on the following symptoms: '{symptoms}', what are some *possible* (non-diagnostic) conditions "
                  "it could indicate? Please provide a list of conditions and a *brief, general* note on each. "
                  "Emphasize strongly that this is not a diagnosis and a qualified medical professional should be consulted for proper diagnosis and treatment. "
                  "Format the response clearly with bullet points or numbered list.")
        try:
            response = self.model.generate_content(prompt)
            if response.candidates and response.candidates[0].content and response.candidates[0].content.parts:
                return response.candidates[0].content.parts[0].text
            else:
                return "I couldn't suggest conditions based on these symptoms. Please rephrase or provide more details."
        except Exception as e:
            return f"An error occurred during prediction: {e}. Please check your API key and internet connection."

    def get_treatment_plan(self, symptoms, age, gender, medical_history):
        """
        Suggests general home remedies and non-prescriptive medication guidelines
        based on symptoms and a basic user profile. Strictly avoids prescriptive advice.

        Args:
            symptoms (str): Current symptoms.
            age (str): User's age.
            gender (str): User's gender.
            medical_history (str): Brief user medical history (or "None").

        Returns:
            str: Suggested home remedies and guidelines, with strong disclaimers.
        """
        # Compile user profile information for context
        user_profile_info = f"Age: {age}, Gender: {gender}, Medical History: {medical_history if medical_history else 'None'}"
        
        # Construct a prompt that enforces non-prescriptive, safe, and general advice
        prompt = (f"Given the symptoms: '{symptoms}' and the user profile ({user_profile_info}), "
                  "please suggest some *general home remedies* and *non-prescriptive, over-the-counter medication guidelines* "
                  "(e.g., 'consider over-the-counter pain relievers like ibuprofen if needed', 'rest and hydration are key'). "
                  "Strictly avoid any prescriptive advice, specific dosages, or diagnosis. "
                  "Always strongly advise consulting a qualified healthcare professional for proper treatment and before taking any medication. "
                  "Provide the suggestions in a clear, easy-to-read format.")
        try:
            response = self.model.generate_content(prompt)
            if response.candidates and response.candidates[0].content and response.candidates[0].content.parts:
                return response.candidates[0].content.parts[0].text
            else:
                return "I couldn't suggest a personalized plan based on your information. Please try again."
        except Exception as e:
            return f"An error occurred during treatment plan generation: {e}. Please check your API key and internet connection."

