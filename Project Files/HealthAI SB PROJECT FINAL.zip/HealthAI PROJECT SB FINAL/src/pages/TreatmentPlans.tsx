import React, { useState } from 'react';
import { Search, Filter, Clock, User, Star, ArrowRight, CheckCircle, X } from 'lucide-react';

const TreatmentPlans = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedPlan, setSelectedPlan] = useState<any>(null);

  const categories = ['All', 'Respiratory', 'Digestive', 'Cardiovascular', 'Mental Health', 'Skin Care', 'Pain Management'];

  const treatmentPlans = [
    {
      id: 1,
      title: 'Common Cold Recovery Plan',
      category: 'Respiratory',
      duration: '7-10 days',
      difficulty: 'Easy',
      rating: 4.8,
      description: 'Comprehensive plan to recover from common cold symptoms with natural and medical approaches.',
      steps: [
        { title: 'Rest and Hydration', duration: '24/7', description: 'Get 8+ hours of sleep, drink plenty of fluids' },
        { title: 'Symptom Management', duration: 'As needed', description: 'Use over-the-counter medications for relief' },
        { title: 'Nutrition Support', duration: 'Daily', description: 'Eat vitamin C rich foods, warm soups' },
        { title: 'Monitoring', duration: 'Daily', description: 'Track temperature and symptom progression' }
      ],
      medications: ['Acetaminophen', 'Decongestants', 'Throat lozenges'],
      tips: ['Use a humidifier', 'Gargle with salt water', 'Avoid smoking and alcohol']
    },
    {
      id: 2,
      title: 'Stress Management Program',
      category: 'Mental Health',
      duration: '21 days',
      difficulty: 'Moderate',
      rating: 4.9,
      description: 'Evidence-based program to reduce stress and improve mental well-being through various techniques.',
      steps: [
        { title: 'Mindfulness Practice', duration: '15 min/day', description: 'Daily meditation and breathing exercises' },
        { title: 'Physical Activity', duration: '30 min/day', description: 'Regular exercise to reduce stress hormones' },
        { title: 'Sleep Hygiene', duration: 'Daily', description: 'Establish consistent sleep schedule' },
        { title: 'Social Connection', duration: 'Weekly', description: 'Maintain relationships and seek support' }
      ],
      medications: [],
      tips: ['Practice deep breathing', 'Limit caffeine intake', 'Keep a stress journal']
    },
    {
      id: 3,
      title: 'Digestive Health Reset',
      category: 'Digestive',
      duration: '14 days',
      difficulty: 'Moderate',
      rating: 4.7,
      description: 'Gentle plan to restore digestive health and reduce gastrointestinal discomfort.',
      steps: [
        { title: 'Dietary Adjustments', duration: 'Daily', description: 'Follow BRAT diet initially, then gradually expand' },
        { title: 'Probiotics', duration: 'Daily', description: 'Include yogurt and fermented foods' },
        { title: 'Hydration', duration: '24/7', description: 'Drink plenty of water and herbal teas' },
        { title: 'Gentle Exercise', duration: '20 min/day', description: 'Light walking to aid digestion' }
      ],
      medications: ['Probiotics', 'Digestive enzymes'],
      tips: ['Eat smaller, frequent meals', 'Avoid spicy foods', 'Chew food thoroughly']
    }
  ];

  const filteredPlans = treatmentPlans.filter(plan => {
    const matchesSearch = plan.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         plan.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || plan.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case 'easy': return 'text-green-600 bg-green-100';
      case 'moderate': return 'text-yellow-600 bg-yellow-100';
      case 'hard': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Treatment Plans</h1>
        <p className="text-lg text-gray-600">
          Personalized, evidence-based treatment plans for various health conditions
        </p>
      </div>

      {/* Search and Filter */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search treatment plans..."
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="pl-10 pr-8 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
            >
              {categories.map((category) => (
                <option key={category} value={category}>{category}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Treatment Plans Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredPlans.map((plan) => (
          <div key={plan.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-lg transition-shadow duration-200">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{plan.title}</h3>
                <p className="text-gray-600 mb-3">{plan.description}</p>
              </div>
              <div className="flex items-center gap-1 text-yellow-500">
                <Star className="h-4 w-4 fill-current" />
                <span className="text-sm font-medium text-gray-700">{plan.rating}</span>
              </div>
            </div>

            <div className="flex items-center gap-4 mb-4">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Clock className="h-4 w-4" />
                {plan.duration}
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <User className="h-4 w-4" />
                {plan.category}
              </div>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(plan.difficulty)}`}>
                {plan.difficulty}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-600">
                {plan.steps.length} steps • {plan.medications.length} medications
              </div>
              <button
                onClick={() => setSelectedPlan(plan)}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
              >
                View Plan
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Plan Details Modal */}
      {selectedPlan && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">{selectedPlan.title}</h2>
                  <p className="text-gray-600 mt-1">{selectedPlan.description}</p>
                </div>
                <button
                  onClick={() => setSelectedPlan(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6">
              {/* Plan Overview */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-blue-50 rounded-lg p-4">
                  <div className="text-sm text-blue-600 font-medium">Duration</div>
                  <div className="text-lg font-semibold text-blue-900">{selectedPlan.duration}</div>
                </div>
                <div className="bg-green-50 rounded-lg p-4">
                  <div className="text-sm text-green-600 font-medium">Difficulty</div>
                  <div className="text-lg font-semibold text-green-900">{selectedPlan.difficulty}</div>
                </div>
                <div className="bg-purple-50 rounded-lg p-4">
                  <div className="text-sm text-purple-600 font-medium">Rating</div>
                  <div className="text-lg font-semibold text-purple-900">{selectedPlan.rating}/5</div>
                </div>
              </div>

              {/* Treatment Steps */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Treatment Steps</h3>
                <div className="space-y-4">
                  {selectedPlan.steps.map((step: any, index: number) => (
                    <div key={index} className="flex gap-4 p-4 bg-gray-50 rounded-lg">
                      <div className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-medium">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-medium text-gray-900">{step.title}</h4>
                          <span className="text-sm text-gray-500">({step.duration})</span>
                        </div>
                        <p className="text-gray-600">{step.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Medications */}
              {selectedPlan.medications.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Recommended Medications</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {selectedPlan.medications.map((medication: string, index: number) => (
                      <div key={index} className="flex items-center gap-2 p-3 bg-green-50 rounded-lg">
                        <CheckCircle className="h-5 w-5 text-green-600" />
                        <span className="text-green-800 font-medium">{medication}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Tips */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Additional Tips</h3>
                <div className="space-y-2">
                  {selectedPlan.tips.map((tip: string, index: number) => (
                    <div key={index} className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">{tip}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-4 pt-4 border-t border-gray-200">
                <button className="flex-1 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors duration-200">
                  Start This Plan
                </button>
                <button className="px-6 py-3 border border-gray-300 text-gray-700 font-semibold rounded-lg hover:bg-gray-50 transition-colors duration-200">
                  Save for Later
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TreatmentPlans;