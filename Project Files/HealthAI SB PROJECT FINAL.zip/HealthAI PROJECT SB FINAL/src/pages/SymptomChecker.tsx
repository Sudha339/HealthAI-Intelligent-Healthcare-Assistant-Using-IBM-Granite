import React, { useState } from 'react';
import { Search, Plus, X, AlertCircle, CheckCircle, Clock } from 'lucide-react';

const SymptomChecker = () => {
  const [symptoms, setSymptoms] = useState<string[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [results, setResults] = useState<any>(null);

  const commonSymptoms = [
    'Fever', 'Headache', 'Cough', 'Sore throat', 'Fatigue', 'Nausea',
    'Body aches', 'Runny nose', 'Shortness of breath', 'Chest pain',
    'Dizziness', 'Stomach pain', 'Diarrhea', 'Vomiting', 'Skin rash'
  ];

  const addSymptom = (symptom: string) => {
    if (symptom && !symptoms.includes(symptom)) {
      setSymptoms([...symptoms, symptom]);
      setInputValue('');
    }
  };

  const removeSymptom = (symptom: string) => {
    setSymptoms(symptoms.filter(s => s !== symptom));
    setResults(null);
  };

  const analyzeSymptoms = async () => {
    if (symptoms.length === 0) return;
    
    setIsAnalyzing(true);
    
    // Simulate AI analysis
    setTimeout(() => {
      const mockResults = {
        possibleConditions: [
          {
            name: 'Common Cold',
            probability: 85,
            severity: 'Mild',
            description: 'A viral infection of the upper respiratory tract',
            recommendations: [
              'Rest and stay hydrated',
              'Use over-the-counter pain relievers',
              'Gargle with warm salt water',
              'Consider decongestants if needed'
            ]
          },
          {
            name: 'Seasonal Allergies',
            probability: 65,
            severity: 'Mild',
            description: 'Allergic reaction to environmental allergens',
            recommendations: [
              'Avoid known allergens',
              'Use antihistamines',
              'Consider nasal sprays',
              'Keep windows closed during high pollen days'
            ]
          },
          {
            name: 'Viral Gastroenteritis',
            probability: 45,
            severity: 'Moderate',
            description: 'Inflammation of the stomach and intestines',
            recommendations: [
              'Stay hydrated with clear fluids',
              'Follow BRAT diet',
              'Rest and avoid solid foods initially',
              'Seek medical care if symptoms worsen'
            ]
          }
        ],
        urgency: 'Low',
        nextSteps: [
          'Monitor symptoms for 24-48 hours',
          'Contact healthcare provider if symptoms worsen',
          'Stay hydrated and get plenty of rest',
          'Follow recommended self-care measures'
        ]
      };
      
      setResults(mockResults);
      setIsAnalyzing(false);
    }, 2000);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity.toLowerCase()) {
      case 'mild': return 'text-green-600 bg-green-100';
      case 'moderate': return 'text-yellow-600 bg-yellow-100';
      case 'severe': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency.toLowerCase()) {
      case 'low': return 'text-green-600 bg-green-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'high': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">AI Symptom Checker</h1>
        <p className="text-lg text-gray-600">
          Describe your symptoms and get AI-powered health insights and recommendations
        </p>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Add Your Symptoms</h2>
        
        {/* Symptom Input */}
        <div className="flex gap-2 mb-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && addSymptom(inputValue)}
              placeholder="Type a symptom..."
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <button
            onClick={() => addSymptom(inputValue)}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center"
          >
            <Plus className="h-5 w-5" />
          </button>
        </div>

        {/* Common Symptoms */}
        <div className="mb-6">
          <p className="text-sm font-medium text-gray-700 mb-3">Common symptoms:</p>
          <div className="flex flex-wrap gap-2">
            {commonSymptoms.map((symptom) => (
              <button
                key={symptom}
                onClick={() => addSymptom(symptom)}
                disabled={symptoms.includes(symptom)}
                className={`px-3 py-1 text-sm rounded-full border transition-colors duration-200 ${
                  symptoms.includes(symptom)
                    ? 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed'
                    : 'bg-white text-gray-700 border-gray-300 hover:bg-blue-50 hover:border-blue-300'
                }`}
              >
                {symptom}
              </button>
            ))}
          </div>
        </div>

        {/* Selected Symptoms */}
        {symptoms.length > 0 && (
          <div className="mb-6">
            <p className="text-sm font-medium text-gray-700 mb-3">Selected symptoms:</p>
            <div className="flex flex-wrap gap-2">
              {symptoms.map((symptom) => (
                <div
                  key={symptom}
                  className="flex items-center gap-2 px-3 py-2 bg-blue-100 text-blue-800 rounded-lg"
                >
                  <span>{symptom}</span>
                  <button
                    onClick={() => removeSymptom(symptom)}
                    className="hover:bg-blue-200 rounded-full p-1"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Analyze Button */}
        <button
          onClick={analyzeSymptoms}
          disabled={symptoms.length === 0 || isAnalyzing}
          className="w-full py-4 bg-gradient-to-r from-blue-600 to-green-600 text-white font-semibold rounded-lg hover:from-blue-700 hover:to-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center"
        >
          {isAnalyzing ? (
            <>
              <Clock className="h-5 w-5 mr-2 animate-spin" />
              Analyzing Symptoms...
            </>
          ) : (
            'Analyze Symptoms'
          )}
        </button>
      </div>

      {/* Results */}
      {results && (
        <div className="space-y-6">
          {/* Urgency Level */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-900">Assessment Results</h2>
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${getUrgencyColor(results.urgency)}`}>
                {results.urgency} Urgency
              </span>
            </div>
          </div>

          {/* Possible Conditions */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Possible Conditions</h3>
            <div className="space-y-4">
              {results.possibleConditions.map((condition: any, index: number) => (
                <div key={index} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold text-gray-900">{condition.name}</h4>
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getSeverityColor(condition.severity)}`}>
                        {condition.severity}
                      </span>
                      <span className="text-sm font-medium text-blue-600">{condition.probability}% match</span>
                    </div>
                  </div>
                  <p className="text-gray-600 mb-3">{condition.description}</p>
                  <div>
                    <p className="text-sm font-medium text-gray-700 mb-2">Recommendations:</p>
                    <ul className="text-sm text-gray-600 space-y-1">
                      {condition.recommendations.map((rec: string, i: number) => (
                        <li key={i} className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                          {rec}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Next Steps */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Recommended Next Steps</h3>
            <ul className="space-y-2">
              {results.nextSteps.map((step: string, index: number) => (
                <li key={index} className="flex items-start gap-2">
                  <AlertCircle className="h-5 w-5 text-blue-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">{step}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Disclaimer */}
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
            <div className="flex items-start gap-2">
              <AlertCircle className="h-5 w-5 text-amber-600 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-amber-800">
                <p className="font-medium mb-1">Medical Disclaimer</p>
                <p>
                  This tool provides general health information and should not replace professional medical advice. 
                  Always consult with a healthcare provider for proper diagnosis and treatment.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SymptomChecker;