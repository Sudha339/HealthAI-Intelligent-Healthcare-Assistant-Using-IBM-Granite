import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Clock, Paperclip, Phone, Video } from 'lucide-react';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  type?: 'text' | 'quick-reply';
}

const PatientChat = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: 'Hello! I\'m your AI health assistant. I\'m here to help you with medical questions, symptom analysis, and health guidance. How can I assist you today?',
      sender: 'ai',
      timestamp: new Date(),
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickReplies = [
    'I have a headache',
    'Check my symptoms',
    'Medication reminder',
    'Emergency help',
    'Schedule appointment',
    'Health tips'
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const generateAIResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('headache')) {
      return 'I understand you\'re experiencing a headache. Here are some immediate steps you can take:\n\n• Stay hydrated - drink plenty of water\n• Rest in a quiet, dark room\n• Apply a cold or warm compress to your head\n• Consider over-the-counter pain relievers if appropriate\n\nIf your headache is severe, sudden, or accompanied by fever, vision changes, or neck stiffness, please seek immediate medical attention.';
    }
    
    if (lowerMessage.includes('symptom')) {
      return 'I can help you analyze your symptoms. Please describe what you\'re experiencing, including:\n\n• When did the symptoms start?\n• How severe are they (1-10 scale)?\n• Any accompanying symptoms?\n• Any recent changes in your routine?\n\nFor a comprehensive symptom analysis, I recommend using our Symptom Checker tool for more detailed assessment.';
    }
    
    if (lowerMessage.includes('emergency')) {
      return '🚨 For medical emergencies, please call 911 immediately.\n\nIf this is not life-threatening but urgent, consider:\n• Calling your doctor\'s after-hours line\n• Visiting an urgent care center\n• Going to the emergency room\n\nI can provide general guidance, but I cannot replace emergency medical care. Your safety is the top priority.';
    }
    
    if (lowerMessage.includes('medication')) {
      return 'I can help with general medication information. Please remember:\n\n• Always follow your doctor\'s instructions\n• Take medications as prescribed\n• Check for drug interactions\n• Store medications properly\n• Never share prescription medications\n\nFor specific medication questions, consult your pharmacist or healthcare provider.';
    }
    
    return 'Thank you for your message. Based on what you\'ve shared, I recommend:\n\n• Monitoring your symptoms\n• Staying hydrated and getting rest\n• Following up with your healthcare provider if symptoms persist\n\nIs there anything specific you\'d like to know more about? I\'m here to help with health questions, symptom guidance, and general wellness advice.';
  };

  const sendMessage = async (content: string) => {
    if (!content.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    // Simulate AI processing time
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: generateAIResponse(content),
        sender: 'ai',
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(inputMessage);
  };

  const handleQuickReply = (reply: string) => {
    sendMessage(reply);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="max-w-4xl mx-auto h-[600px] bg-white rounded-xl shadow-sm border border-gray-100 flex flex-col">
      {/* Chat Header */}
      <div className="p-4 border-b border-gray-200 bg-gradient-to-r from-blue-600 to-green-600 rounded-t-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
              <Bot className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <h3 className="font-semibold text-white">HealthAI Assistant</h3>
              <p className="text-blue-100 text-sm">Online • Responds instantly</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="p-2 text-white hover:bg-white/20 rounded-lg transition-colors duration-200">
              <Phone className="h-5 w-5" />
            </button>
            <button className="p-2 text-white hover:bg-white/20 rounded-lg transition-colors duration-200">
              <Video className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div className={`flex items-start gap-2 max-w-xs lg:max-w-md ${
              message.sender === 'user' ? 'flex-row-reverse' : 'flex-row'
            }`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                message.sender === 'user' 
                  ? 'bg-blue-600' 
                  : 'bg-gradient-to-r from-blue-600 to-green-600'
              }`}>
                {message.sender === 'user' ? (
                  <User className="h-4 w-4 text-white" />
                ) : (
                  <Bot className="h-4 w-4 text-white" />
                )}
              </div>
              <div>
                <div className={`p-3 rounded-lg ${
                  message.sender === 'user'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-900'
                }`}>
                  <p className="whitespace-pre-line">{message.content}</p>
                </div>
                <div className={`flex items-center gap-1 mt-1 text-xs text-gray-500 ${
                  message.sender === 'user' ? 'justify-end' : 'justify-start'
                }`}>
                  <Clock className="h-3 w-3" />
                  {formatTime(message.timestamp)}
                </div>
              </div>
            </div>
          </div>
        ))}

        {/* Typing Indicator */}
        {isTyping && (
          <div className="flex justify-start">
            <div className="flex items-start gap-2 max-w-xs lg:max-w-md">
              <div className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-600 to-green-600 flex items-center justify-center">
                <Bot className="h-4 w-4 text-white" />
              </div>
              <div className="bg-gray-100 p-3 rounded-lg">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Replies */}
      <div className="p-4 border-t border-gray-200">
        <div className="flex flex-wrap gap-2 mb-3">
          {quickReplies.map((reply, index) => (
            <button
              key={index}
              onClick={() => handleQuickReply(reply)}
              className="px-3 py-1 text-sm bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200 transition-colors duration-200"
            >
              {reply}
            </button>
          ))}
        </div>

        {/* Message Input */}
        <form onSubmit={handleSubmit} className="flex items-center gap-2">
          <button
            type="button"
            className="p-2 text-gray-400 hover:text-gray-600 transition-colors duration-200"
          >
            <Paperclip className="h-5 w-5" />
          </button>
          <div className="flex-1 relative">
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Type your health question..."
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              disabled={isTyping}
            />
          </div>
          <button
            type="submit"
            disabled={!inputMessage.trim() || isTyping}
            className="p-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
          >
            <Send className="h-5 w-5" />
          </button>
        </form>
      </div>
    </div>
  );
};

export default PatientChat;