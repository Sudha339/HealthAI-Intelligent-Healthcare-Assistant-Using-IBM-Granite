import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Activity, 
  Stethoscope, 
  FileText, 
  BarChart3, 
  MessageCircle, 
  AlertTriangle,
  TrendingUp,
  Users,
  Clock,
  CheckCircle
} from 'lucide-react';

const Dashboard = () => {
  const quickStats = [
    { title: 'Health Score', value: '85%', icon: Activity, color: 'green' },
    { title: 'Consultations', value: '24', icon: Users, color: 'blue' },
    { title: 'Avg Response Time', value: '2.3s', icon: Clock, color: 'purple' },
    { title: 'Accuracy Rate', value: '94.2%', icon: CheckCircle, color: 'emerald' },
  ];

  const features = [
    {
      title: 'Symptom Checker',
      description: 'AI-powered disease prediction based on your symptoms',
      icon: Stethoscope,
      link: '/symptoms',
      color: 'blue',
    },
    {
      title: 'Treatment Plans',
      description: 'Personalized treatment recommendations and health guidance',
      icon: FileText,
      link: '/treatments',
      color: 'green',
    },
    {
      title: 'Health Analytics',
      description: 'Comprehensive insights into your health patterns and trends',
      icon: BarChart3,
      link: '/analytics',
      color: 'purple',
    },
    {
      title: 'Patient Chat',
      description: '24/7 AI health assistant for immediate medical guidance',
      icon: MessageCircle,
      link: '/chat',
      color: 'indigo',
    },
    {
      title: 'Emergency Helper',
      description: 'Rapid assessment and guidance for urgent health situations',
      icon: AlertTriangle,
      link: '/emergency',
      color: 'red',
    },
  ];

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="text-center py-12">
        <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
          Welcome to <span className="bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent">HealthAI</span>
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Your intelligent healthcare assistant powered by advanced AI to provide accurate health insights, 
          personalized treatment plans, and 24/7 medical guidance.
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {quickStats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-lg transition-shadow duration-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div className={`p-3 rounded-lg bg-${stat.color}-100`}>
                  <Icon className={`h-6 w-6 text-${stat.color}-600`} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Features Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {features.map((feature, index) => {
          const Icon = feature.icon;
          return (
            <Link
              key={index}
              to={feature.link}
              className="group bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-xl hover:border-blue-200 transition-all duration-300 transform hover:-translate-y-1"
            >
              <div className={`inline-flex p-3 rounded-lg bg-${feature.color}-100 mb-4 group-hover:scale-110 transition-transform duration-200`}>
                <Icon className={`h-6 w-6 text-${feature.color}-600`} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                {feature.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
              <div className="flex items-center mt-4 text-blue-600 font-medium">
                <span>Get Started</span>
                <TrendingUp className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform duration-200" />
              </div>
            </Link>
          );
        })}
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-2xl p-8 text-center text-white">
        <h2 className="text-3xl font-bold mb-4">Ready to Transform Your Healthcare Experience?</h2>
        <p className="text-xl mb-6 opacity-90">
          Start your journey with AI-powered health insights and personalized care recommendations.
        </p>
        <Link
          to="/symptoms"
          className="inline-flex items-center px-8 py-3 bg-white text-blue-600 font-semibold rounded-lg hover:bg-gray-100 transition-colors duration-200"
        >
          <Stethoscope className="h-5 w-5 mr-2" />
          Check Your Symptoms Now
        </Link>
      </div>
    </div>
  );
};

export default Dashboard;