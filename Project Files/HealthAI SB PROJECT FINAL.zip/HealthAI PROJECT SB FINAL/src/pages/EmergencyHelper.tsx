import React, { useState } from 'react';
import { AlertTriangle, Phone, MapPin, Clock, Heart, Thermometer, Activity } from 'lucide-react';

const EmergencyHelper = () => {
  const [selectedEmergency, setSelectedEmergency] = useState<string | null>(null);

  const emergencyTypes = [
    {
      id: 'chest-pain',
      title: 'Chest Pain',
      icon: Heart,
      color: 'red',
      urgency: 'CALL 911 IMMEDIATELY',
      description: 'Severe chest pain, pressure, or discomfort'
    },
    {
      id: 'breathing',
      title: 'Breathing Problems',
      icon: Activity,
      color: 'red',
      urgency: 'CALL 911 IMMEDIATELY',
      description: 'Severe difficulty breathing or shortness of breath'
    },
    {
      id: 'unconscious',
      title: 'Unconsciousness',
      icon: AlertTriangle,
      color: 'red',
      urgency: 'CALL 911 IMMEDIATELY',
      description: 'Person is unconscious or unresponsive'
    },
    {
      id: 'severe-bleeding',
      title: 'Severe Bleeding',
      icon: AlertTriangle,
      color: 'red',
      urgency: 'CALL 911 IMMEDIATELY',
      description: 'Heavy bleeding that won\'t stop'
    },
    {
      id: 'high-fever',
      title: 'High Fever',
      icon: Thermometer,
      color: 'orange',
      urgency: 'SEEK IMMEDIATE CARE',
      description: 'Fever over 103°F (39.4°C) or with severe symptoms'
    },
    {
      id: 'allergic-reaction',
      title: 'Severe Allergic Reaction',
      icon: AlertTriangle,
      color: 'red',
      urgency: 'CALL 911 IMMEDIATELY',
      description: 'Difficulty breathing, swelling, or severe reaction'
    }
  ];

  const emergencySteps = {
    'chest-pain': [
      'Call 911 immediately',
      'Have the person sit down and rest',
      'Loosen any tight clothing',
      'If prescribed, help them take nitroglycerin',
      'If available and not allergic, give aspirin',
      'Monitor breathing and pulse',
      'Be prepared to perform CPR if needed'
    ],
    'breathing': [
      'Call 911 immediately',
      'Help the person sit upright',
      'Loosen tight clothing around neck/chest',
      'If they have an inhaler, help them use it',
      'Stay calm and reassure them',
      'Monitor their condition closely',
      'Be prepared to perform rescue breathing'
    ],
    'unconscious': [
      'Call 911 immediately',
      'Check for responsiveness',
      'Check for breathing and pulse',
      'If no breathing/pulse, start CPR',
      'Place in recovery position if breathing',
      'Do not give food or water',
      'Stay with them until help arrives'
    ],
    'severe-bleeding': [
      'Call 911 immediately',
      'Apply direct pressure to the wound',
      'Use a clean cloth or bandage',
      'Elevate the injured area if possible',
      'Do not remove objects from the wound',
      'Apply additional bandages if blood soaks through',
      'Treat for shock if necessary'
    ],
    'high-fever': [
      'Seek immediate medical care',
      'Monitor temperature regularly',
      'Give fluids to prevent dehydration',
      'Use fever-reducing medication as appropriate',
      'Apply cool, damp cloths to forehead',
      'Remove excess clothing/blankets',
      'Watch for signs of dehydration or confusion'
    ],
    'allergic-reaction': [
      'Call 911 immediately',
      'Use epinephrine auto-injector if available',
      'Help the person lie down with legs elevated',
      'Loosen tight clothing',
      'Cover with a blanket',
      'Do not give anything by mouth',
      'Be prepared to perform CPR'
    ]
  };

  const warningSignsAll = [
    'Sudden severe headache',
    'Sudden vision changes',
    'Sudden speech difficulties',
    'Sudden weakness or numbness',
    'Signs of stroke (FAST test)',
    'Severe abdominal pain',
    'Coughing or vomiting blood',
    'Signs of poisoning'
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Emergency Banner */}
      <div className="bg-red-600 text-white rounded-xl p-6 text-center">
        <div className="flex items-center justify-center gap-3 mb-4">
          <AlertTriangle className="h-8 w-8" />
          <h1 className="text-3xl font-bold">Emergency Medical Helper</h1>
        </div>
        <p className="text-xl mb-4">For life-threatening emergencies, call 911 immediately</p>
        <div className="flex items-center justify-center gap-6 text-sm">
          <div className="flex items-center gap-2">
            <Phone className="h-4 w-4" />
            Emergency: 911
          </div>
          <div className="flex items-center gap-2">
            <Phone className="h-4 w-4" />
            Poison Control: 1-800-222-1222
          </div>
        </div>
      </div>

      {!selectedEmergency ? (
        <>
          {/* Quick Assessment */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Select Emergency Type</h2>
            <p className="text-gray-600 mb-6">
              Choose the situation that best describes your emergency for immediate guidance
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {emergencyTypes.map((emergency) => {
                const Icon = emergency.icon;
                return (
                  <button
                    key={emergency.id}
                    onClick={() => setSelectedEmergency(emergency.id)}
                    className={`p-4 border-2 rounded-lg text-left transition-all duration-200 hover:shadow-lg ${
                      emergency.color === 'red' 
                        ? 'border-red-200 hover:border-red-400 bg-red-50' 
                        : 'border-orange-200 hover:border-orange-400 bg-orange-50'
                    }`}
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <div className={`p-2 rounded-lg ${
                        emergency.color === 'red' ? 'bg-red-100' : 'bg-orange-100'
                      }`}>
                        <Icon className={`h-6 w-6 ${
                          emergency.color === 'red' ? 'text-red-600' : 'text-orange-600'
                        }`} />
                      </div>
                      <h3 className="font-semibold text-gray-900">{emergency.title}</h3>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{emergency.description}</p>
                    <span className={`text-xs font-bold ${
                      emergency.color === 'red' ? 'text-red-600' : 'text-orange-600'
                    }`}>
                      {emergency.urgency}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* General Warning Signs */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">General Warning Signs</h2>
            <p className="text-gray-600 mb-4">Call 911 immediately if you experience any of these symptoms:</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {warningSignsAll.map((sign, index) => (
                <div key={index} className="flex items-center gap-2 p-3 bg-red-50 rounded-lg">
                  <AlertTriangle className="h-4 w-4 text-red-600 flex-shrink-0" />
                  <span className="text-red-800">{sign}</span>
                </div>
              ))}
            </div>
          </div>

          {/* FAST Stroke Test */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">FAST Stroke Test</h2>
            <p className="text-gray-600 mb-4">Use this test to quickly identify signs of stroke:</p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <h3 className="font-semibold text-blue-900 mb-2">F - Face</h3>
                <p className="text-sm text-blue-800">Ask the person to smile. Does one side droop?</p>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <h3 className="font-semibold text-green-900 mb-2">A - Arms</h3>
                <p className="text-sm text-green-800">Ask them to raise both arms. Does one drift down?</p>
              </div>
              <div className="p-4 bg-purple-50 rounded-lg">
                <h3 className="font-semibold text-purple-900 mb-2">S - Speech</h3>
                <p className="text-sm text-purple-800">Ask them to repeat a phrase. Is it slurred?</p>
              </div>
              <div className="p-4 bg-red-50 rounded-lg">
                <h3 className="font-semibold text-red-900 mb-2">T - Time</h3>
                <p className="text-sm text-red-800">If any signs present, call 911 immediately!</p>
              </div>
            </div>
          </div>
        </>
      ) : (
        /* Emergency Steps */
        <div className="space-y-6">
          <button
            onClick={() => setSelectedEmergency(null)}
            className="text-blue-600 hover:text-blue-700 font-medium"
          >
            ← Back to Emergency Types
          </button>

          <div className="bg-red-600 text-white rounded-xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <AlertTriangle className="h-8 w-8" />
              <div>
                <h2 className="text-2xl font-bold">
                  {emergencyTypes.find(e => e.id === selectedEmergency)?.title}
                </h2>
                <p className="text-red-100">
                  {emergencyTypes.find(e => e.id === selectedEmergency)?.urgency}
                </p>
              </div>
            </div>
            <div className="bg-red-700 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Phone className="h-5 w-5" />
                <span className="font-semibold">Call 911 Now: </span>
              </div>
              <p>Tell them: "{emergencyTypes.find(e => e.id === selectedEmergency)?.description}"</p>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Immediate Steps to Take</h3>
            <div className="space-y-4">
              {emergencySteps[selectedEmergency as keyof typeof emergencySteps]?.map((step, index) => (
                <div key={index} className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
                  <div className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                    {index + 1}
                  </div>
                  <div>
                    <p className="text-gray-900 font-medium">{step}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
            <div className="flex items-start gap-2">
              <Clock className="h-5 w-5 text-amber-600 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-amber-800">
                <p className="font-medium mb-1">Important Reminders</p>
                <ul className="space-y-1">
                  <li>• Stay calm and follow emergency operator instructions</li>
                  <li>• Do not leave the person alone unless getting help</li>
                  <li>• Be prepared to provide your location clearly</li>
                  <li>• Have medical information ready if available</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmergencyHelper;