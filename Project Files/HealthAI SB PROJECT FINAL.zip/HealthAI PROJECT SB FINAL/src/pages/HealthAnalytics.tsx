import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Heart, Activity, Calendar, Target, AlertCircle } from 'lucide-react';

const HealthAnalytics = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('7d');

  const periods = [
    { value: '7d', label: '7 Days' },
    { value: '30d', label: '30 Days' },
    { value: '90d', label: '90 Days' },
    { value: '1y', label: '1 Year' }
  ];

  const healthScoreData = [
    { date: 'Mon', score: 85 },
    { date: 'Tue', score: 88 },
    { date: 'Wed', score: 82 },
    { date: 'Thu', score: 90 },
    { date: 'Fri', score: 87 },
    { date: 'Sat', score: 92 },
    { date: 'Sun', score: 89 }
  ];

  const symptomTrendData = [
    { month: 'Jan', respiratory: 12, digestive: 8, other: 5 },
    { month: 'Feb', respiratory: 8, digestive: 6, other: 3 },
    { month: 'Mar', respiratory: 15, digestive: 10, other: 7 },
    { month: 'Apr', respiratory: 6, digestive: 4, other: 2 },
    { month: 'May', respiratory: 10, digestive: 7, other: 4 },
    { month: 'Jun', respiratory: 4, digestive: 3, other: 1 }
  ];

  const conditionDistribution = [
    { name: 'Respiratory', value: 45, color: '#3B82F6' },
    { name: 'Digestive', value: 25, color: '#10B981' },
    { name: 'Cardiovascular', value: 15, color: '#F59E0B' },
    { name: 'Mental Health', value: 10, color: '#8B5CF6' },
    { name: 'Other', value: 5, color: '#EF4444' }
  ];

  const healthMetrics = [
    {
      title: 'Health Score',
      value: '89',
      unit: '/100',
      change: '+5%',
      trend: 'up',
      icon: Heart,
      color: 'green'
    },
    {
      title: 'Consultations',
      value: '24',
      unit: 'this month',
      change: '-12%',
      trend: 'down',
      icon: Activity,
      color: 'blue'
    },
    {
      title: 'Avg Response Time',
      value: '2.3',
      unit: 'seconds',
      change: '-0.5s',
      trend: 'down',
      icon: TrendingUp,
      color: 'purple'
    },
    {
      title: 'Follow-ups',
      value: '8',
      unit: 'pending',
      change: '+2',
      trend: 'up',
      icon: Calendar,
      color: 'orange'
    }
  ];

  const recentInsights = [
    {
      type: 'improvement',
      title: 'Sleep Quality Improved',
      description: 'Your sleep score has increased by 15% over the past week',
      time: '2 hours ago'
    },
    {
      type: 'alert',
      title: 'Stress Levels Rising',
      description: 'Consider implementing stress management techniques',
      time: '1 day ago'
    },
    {
      type: 'achievement',
      title: 'Health Goal Achieved',
      description: 'You\'ve successfully completed your 30-day wellness plan',
      time: '3 days ago'
    }
  ];

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'improvement': return <TrendingUp className="h-5 w-5 text-green-600" />;
      case 'alert': return <AlertCircle className="h-5 w-5 text-amber-600" />;
      case 'achievement': return <Target className="h-5 w-5 text-blue-600" />;
      default: return <Activity className="h-5 w-5 text-gray-600" />;
    }
  };

  const getInsightColor = (type: string) => {
    switch (type) {
      case 'improvement': return 'bg-green-50 border-green-200';
      case 'alert': return 'bg-amber-50 border-amber-200';
      case 'achievement': return 'bg-blue-50 border-blue-200';
      default: return 'bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Health Analytics</h1>
          <p className="text-lg text-gray-600">
            Comprehensive insights into your health patterns and trends
          </p>
        </div>
        <div className="flex gap-2">
          {periods.map((period) => (
            <button
              key={period.value}
              onClick={() => setSelectedPeriod(period.value)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors duration-200 ${
                selectedPeriod === period.value
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-600 border border-gray-300 hover:bg-gray-50'
              }`}
            >
              {period.label}
            </button>
          ))}
        </div>
      </div>

      {/* Health Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {healthMetrics.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg bg-${metric.color}-100`}>
                  <Icon className={`h-6 w-6 text-${metric.color}-600`} />
                </div>
                <span className={`text-sm font-medium ${
                  metric.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {metric.change}
                </span>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-600 mb-1">{metric.title}</h3>
                <div className="flex items-baseline">
                  <span className="text-2xl font-bold text-gray-900">{metric.value}</span>
                  <span className="text-sm text-gray-500 ml-1">{metric.unit}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Health Score Trend */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Health Score Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={healthScoreData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
              <XAxis dataKey="date" stroke="#6B7280" />
              <YAxis stroke="#6B7280" domain={[70, 100]} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white', 
                  border: '1px solid #E5E7EB',
                  borderRadius: '8px',
                  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="score" 
                stroke="#3B82F6" 
                strokeWidth={3}
                dot={{ fill: '#3B82F6', strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6, stroke: '#3B82F6', strokeWidth: 2 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Condition Distribution */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Condition Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={conditionDistribution}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={5}
                dataKey="value"
              >
                {conditionDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white', 
                  border: '1px solid #E5E7EB',
                  borderRadius: '8px',
                  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-2 gap-2 mt-4">
            {conditionDistribution.map((item, index) => (
              <div key={index} className="flex items-center gap-2">
                <div 
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: item.color }}
                />
                <span className="text-sm text-gray-600">{item.name}</span>
                <span className="text-sm font-medium text-gray-900">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Symptom Trends */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Symptom Trends (Last 6 Months)</h3>
        <ResponsiveContainer width="100%" height={400}>
          <BarChart data={symptomTrendData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
            <XAxis dataKey="month" stroke="#6B7280" />
            <YAxis stroke="#6B7280" />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'white', 
                border: '1px solid #E5E7EB',
                borderRadius: '8px',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
              }}
            />
            <Bar dataKey="respiratory" stackId="a" fill="#3B82F6" name="Respiratory" />
            <Bar dataKey="digestive" stackId="a" fill="#10B981" name="Digestive" />
            <Bar dataKey="other" stackId="a" fill="#F59E0B" name="Other" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Recent Insights */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Health Insights</h3>
        <div className="space-y-4">
          {recentInsights.map((insight, index) => (
            <div key={index} className={`p-4 rounded-lg border ${getInsightColor(insight.type)}`}>
              <div className="flex items-start gap-3">
                {getInsightIcon(insight.type)}
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900 mb-1">{insight.title}</h4>
                  <p className="text-gray-600 text-sm mb-2">{insight.description}</p>
                  <span className="text-xs text-gray-500">{insight.time}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HealthAnalytics;