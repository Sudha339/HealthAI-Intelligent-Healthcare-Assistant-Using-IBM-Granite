import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Dashboard from './pages/Dashboard';
import SymptomChecker from './pages/SymptomChecker';
import TreatmentPlans from './pages/TreatmentPlans';
import HealthAnalytics from './pages/HealthAnalytics';
import PatientChat from './pages/PatientChat';
import EmergencyHelper from './pages/EmergencyHelper';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
        <Navbar />
        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/symptoms" element={<SymptomChecker />} />
            <Route path="/treatments" element={<TreatmentPlans />} />
            <Route path="/analytics" element={<HealthAnalytics />} />
            <Route path="/chat" element={<PatientChat />} />
            <Route path="/emergency" element={<EmergencyHelper />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;