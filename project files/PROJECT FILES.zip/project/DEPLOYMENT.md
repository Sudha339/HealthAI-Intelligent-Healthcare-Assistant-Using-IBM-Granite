# Deployment Guide for HealthAI

## Quick Deployment Options

### 1. Netlify (Recommended)
1. Connect your GitHub repository to Netlify
2. Set build command: `npm run build`
3. Set publish directory: `dist`
4. Deploy automatically on push

### 2. Vercel
1. Import project from GitHub
2. Framework preset: Vite
3. Build command: `npm run build`
4. Output directory: `dist`

### 3. GitHub Pages
1. Install gh-pages: `npm install --save-dev gh-pages`
2. Add to package.json scripts:
   ```json
   "deploy": "gh-pages -d dist"
   ```
3. Run: `npm run build && npm run deploy`

## Environment Configuration

Create `.env` file for environment variables:
```
VITE_APP_NAME=HealthAI
VITE_API_URL=your-api-url
```

## Build Optimization

The application is optimized for production with:
- Code splitting
- Asset optimization
- Tree shaking
- Minification

## Performance Considerations

- Lazy loading for components
- Image optimization
- Bundle size monitoring
- Caching strategies

## Security Headers

Recommended security headers for production:
```
X-Frame-Options: DENY
X-Content-Type-Options: nosniff
Referrer-Policy: strict-origin-when-cross-origin
```