# HealthAI - Intelligent Healthcare Assistant

A comprehensive healthcare assistant application powered by AI technology, providing intelligent health guidance, disease prediction, and personalized treatment recommendations.

## Features

### 🤖 AI Chat Assistant
- Interactive health consultation with AI-powered responses
- Non-diagnostic health information and guidance
- Context-aware conversations about symptoms and wellness
- Safe, reliable health information with proper disclaimers

### 🔍 Disease Prediction
- Symptom-based condition analysis
- AI-powered probability assessment
- Multiple condition suggestions with detailed descriptions
- Severity-based symptom tracking

### 💊 Personalized Treatment Plans
- Customized treatment recommendations
- Home remedies and lifestyle suggestions
- Medication guidelines (non-prescriptive)
- User profile-based personalization

### 📊 Health Dashboard
- Interactive health data visualization
- Vital signs tracking and trends
- Sleep, activity, and mood monitoring
- AI-generated health insights

### 👤 User Profile Management
- Comprehensive health profile setup
- Medical history and allergy tracking
- Emergency contact information
- Personalized recommendations based on profile

## Technology Stack

- **Frontend**: React 18 with TypeScript
- **Styling**: Tailwind CSS
- **Charts**: Recharts for data visualization
- **Icons**: Lucide React
- **Build Tool**: Vite
- **Deployment**: Netlify

## Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd healthai-assistant
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Build for production:
```bash
npm run build
```

## Project Structure

```
src/
├── components/           # React components
│   ├── Header.tsx       # Application header
│   ├── Navigation.tsx   # Navigation menu
│   ├── ChatAssistant.tsx # AI chat interface
│   ├── DiseasePrediction.tsx # Disease prediction
│   ├── TreatmentPlans.tsx # Treatment recommendations
│   ├── HealthDashboard.tsx # Health data visualization
│   └── UserProfile.tsx  # User profile management
├── contexts/            # React contexts
│   └── UserContext.tsx  # User state management
├── utils/              # Utility functions
│   ├── aiSimulator.ts  # AI response simulation
│   ├── diseasePredictor.ts # Disease prediction logic
│   └── treatmentGenerator.ts # Treatment plan generation
├── App.tsx             # Main application component
├── main.tsx            # Application entry point
└── index.css           # Global styles
```

## Key Features Implementation

### AI Chat Assistant
- Simulated AI responses with health-focused knowledge base
- Context-aware conversation handling
- Emergency keyword detection
- Proper medical disclaimers

### Disease Prediction Engine
- Symptom matching algorithm
- Probability calculation based on symptom severity
- Multiple condition suggestions
- Urgency level assessment

### Treatment Plan Generator
- Personalized recommendations based on user profile
- Age and condition-specific adjustments
- Allergy and medication interaction warnings
- Comprehensive treatment categories

### Health Data Visualization
- Interactive charts for health metrics
- Trend analysis and insights
- Real-time data updates
- Mobile-responsive design

## Safety & Compliance

- **Medical Disclaimers**: Clear warnings that this is not medical advice
- **Emergency Guidance**: Proper direction to seek immediate care when needed
- **Data Privacy**: User data handled securely
- **Non-Prescriptive**: All recommendations are informational only

## Development Guidelines

### Code Organization
- Modular component architecture
- TypeScript for type safety
- Consistent naming conventions
- Comprehensive error handling

### Styling
- Tailwind CSS utility classes
- Responsive design principles
- Accessibility considerations
- Healthcare-appropriate color scheme

### Data Management
- React Context for state management
- Local storage for user preferences
- Simulated API responses
- Type-safe data structures

## Deployment

The application is configured for easy deployment on platforms like Netlify, Vercel, or any static hosting service.

### Build Commands
```bash
npm run build    # Build for production
npm run preview  # Preview production build
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is for educational and demonstration purposes. Always consult healthcare professionals for medical advice.

## Disclaimer

This application is for informational purposes only and is not intended to provide medical advice, diagnosis, or treatment. Always seek the advice of qualified healthcare providers with any questions regarding your health condition.