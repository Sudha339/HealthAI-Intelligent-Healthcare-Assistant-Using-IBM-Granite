import React, { createContext, useContext, useState, ReactNode } from 'react';

export type User = {
  name: string;
  age: number;
  gender: string;
  height: string;
  weight: string;
  conditions: string[];
  allergies: string[];
  medications: string[];
  emergencyContact: string;
};

type UserContextType = {
  user: User | null;
  updateUser: (userData: User) => void;
};

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>({
    name: 'Alex Johnson',
    age: 28,
    gender: 'Other',
    height: '5\'8"',
    weight: '155 lbs',
    conditions: ['Seasonal Allergies'],
    allergies: ['Pollen', 'Dust'],
    medications: ['Multivitamin'],
    emergencyContact: '(555) 123-4567'
  });

  const updateUser = (userData: User) => {
    setUser(userData);
  };

  return (
    <UserContext.Provider value={{ user, updateUser }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};