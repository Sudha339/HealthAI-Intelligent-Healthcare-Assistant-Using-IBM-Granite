import React, { useState } from 'react';
import Header from './components/Header';
import Navigation from './components/Navigation';
import ChatAssistant from './components/ChatAssistant';
import DiseasePrediction from './components/DiseasePrediction';
import TreatmentPlans from './components/TreatmentPlans';
import HealthDashboard from './components/HealthDashboard';
import UserProfile from './components/UserProfile';
import { UserProvider } from './contexts/UserContext';

type ActiveTab = 'chat' | 'prediction' | 'treatment' | 'dashboard' | 'profile';

function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('chat');

  const renderActiveComponent = () => {
    switch (activeTab) {
      case 'chat':
        return <ChatAssistant />;
      case 'prediction':
        return <DiseasePrediction />;
      case 'treatment':
        return <TreatmentPlans />;
      case 'dashboard':
        return <HealthDashboard />;
      case 'profile':
        return <UserProfile />;
      default:
        return <ChatAssistant />;
    }
  };

  return (
    <UserProvider>
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-cyan-400/20 to-blue-600/20 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-emerald-400/20 to-teal-600/20 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-br from-purple-400/10 to-pink-600/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '4s'}}></div>
        </div>
        
        {/* Glass morphism overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-sm"></div>
        
        <div className="relative z-10">
        <Header />
        <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
        <main className="container mx-auto px-4 py-8">
          {renderActiveComponent()}
        </main>
        </div>
      </div>
    </UserProvider>
  );
}

export default App;