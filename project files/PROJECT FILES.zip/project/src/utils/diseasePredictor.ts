type Symptom = {
  id: string;
  name: string;
  severity: 'mild' | 'moderate' | 'severe';
};

type Prediction = {
  condition: string;
  probability: number;
  description: string;
  recommendations: string[];
  urgency: 'low' | 'medium' | 'high';
};

const diseaseDatabase: Record<string, { 
  symptoms: string[], 
  description: string, 
  recommendations: string[],
  urgency: 'low' | 'medium' | 'high'
}> = {
  'Common Cold': {
    symptoms: ['runny nose', 'sore throat', 'cough', 'sneezing', 'mild headache'],
    description: 'A viral infection affecting the upper respiratory tract, typically lasting 7-10 days.',
    recommendations: [
      'Get plenty of rest and stay hydrated',
      'Use saline nasal drops to clear congestion',
      'Consider over-the-counter pain relievers if needed',
      'Gargle with warm salt water for sore throat'
    ],
    urgency: 'low'
  },
  'Influenza (Flu)': {
    symptoms: ['fever', 'muscle aches', 'fatigue', 'cough', 'headache', 'chills'],
    description: 'A viral respiratory infection that can cause severe illness, typically lasting 1-2 weeks.',
    recommendations: [
      'Rest and increase fluid intake significantly',
      'Consider antiviral medication if within 48 hours of symptom onset',
      'Monitor temperature and seek care if fever is very high',
      'Stay home to avoid spreading infection'
    ],
    urgency: 'medium'
  },
  'Migraine': {
    symptoms: ['severe headache', 'nausea', 'sensitivity to light', 'dizziness'],
    description: 'A neurological condition causing intense headaches, often with additional symptoms.',
    recommendations: [
      'Rest in a dark, quiet room',
      'Apply cold or warm compress to head or neck',
      'Stay hydrated and maintain regular sleep schedule',
      'Consider keeping a headache diary to identify triggers'
    ],
    urgency: 'medium'
  },
  'Gastroenteritis': {
    symptoms: ['nausea', 'vomiting', 'diarrhea', 'abdominal pain', 'fatigue'],
    description: 'Inflammation of the stomach and intestines, often caused by viral or bacterial infection.',
    recommendations: [
      'Stay hydrated with clear fluids and electrolyte solutions',
      'Follow the BRAT diet (bananas, rice, applesauce, toast)',
      'Avoid dairy and fatty foods temporarily',
      'Rest and avoid solid foods until vomiting stops'
    ],
    urgency: 'medium'
  },
  'Tension Headache': {
    symptoms: ['headache', 'muscle tension', 'stress', 'fatigue'],
    description: 'The most common type of headache, often related to stress and muscle tension.',
    recommendations: [
      'Practice stress management techniques',
      'Apply heat or cold to head, neck, or shoulders',
      'Consider over-the-counter pain relievers',
      'Maintain regular sleep and meal schedules'
    ],
    urgency: 'low'
  },
  'Allergic Reaction': {
    symptoms: ['rash', 'itching', 'sneezing', 'runny nose', 'watery eyes'],
    description: 'Body\'s immune response to allergens, ranging from mild to severe.',
    recommendations: [
      'Identify and avoid known allergens',
      'Consider antihistamines for symptom relief',
      'Use cool compresses for skin irritation',
      'Seek immediate care if experiencing difficulty breathing'
    ],
    urgency: 'low'
  }
};

export const predictDisease = async (symptoms: Symptom[]): Promise<Prediction[]> => {
  // Simulate AI processing
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  const symptomNames = symptoms.map(s => s.name.toLowerCase());
  const predictions: Prediction[] = [];
  
  // Calculate probability for each disease
  for (const [disease, data] of Object.entries(diseaseDatabase)) {
    let matchCount = 0;
    let severityBonus = 0;
    
    // Count symptom matches
    for (const symptom of symptoms) {
      if (data.symptoms.some(ds => ds.includes(symptom.name.toLowerCase()) || symptom.name.toLowerCase().includes(ds))) {
        matchCount++;
        // Add bonus for severity
        if (symptom.severity === 'severe') severityBonus += 0.2;
        else if (symptom.severity === 'moderate') severityBonus += 0.1;
      }
    }
    
    // Calculate base probability
    const baseProbability = (matchCount / data.symptoms.length) * 100;
    const finalProbability = Math.min(95, Math.max(5, baseProbability + (severityBonus * 100)));
    
    if (matchCount > 0) {
      predictions.push({
        condition: disease,
        probability: Math.round(finalProbability),
        description: data.description,
        recommendations: data.recommendations,
        urgency: data.urgency
      });
    }
  }
  
  // Sort by probability and return top matches
  return predictions
    .sort((a, b) => b.probability - a.probability)
    .slice(0, 4);
};