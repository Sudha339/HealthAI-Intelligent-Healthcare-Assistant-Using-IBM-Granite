const healthResponses = {
  symptoms: [
    "Based on your symptoms, there could be several possibilities. However, I recommend consulting with a healthcare professional for proper evaluation.",
    "I understand you're experiencing some symptoms. While I can provide general information, it's important to get a proper medical assessment.",
    "Symptoms can have various causes, and proper diagnosis requires medical expertise. Please consider seeing a healthcare provider."
  ],
  general: [
    "That's a great health question! Here's some general information that might help, but always consult your doctor for personalized advice.",
    "I'm here to provide general health information. For your specific situation, it's best to speak with a qualified healthcare professional.",
    "Thank you for your question about health. I can share some general insights, though individual cases vary significantly."
  ],
  emergency: [
    "This sounds like it could be serious. Please seek immediate medical attention or call emergency services if you're experiencing severe symptoms.",
    "If you're having a medical emergency, please call emergency services immediately. Don't delay seeking professional help.",
    "Your safety is the priority. If this is urgent, please contact emergency services or go to the nearest emergency room."
  ]
};

const keywordResponses: Record<string, string> = {
  'headache': "Headaches can have many causes including stress, dehydration, lack of sleep, or tension. For frequent or severe headaches, consider seeing a healthcare provider. In the meantime, ensure you're staying hydrated, getting adequate rest, and managing stress levels.",
  
  'fever': "A fever is often your body's way of fighting infection. For adults, a temperature over 100.4°F (38°C) is considered a fever. Stay hydrated, rest, and monitor your temperature. Seek medical care if fever is high (over 103°F/39.4°C) or persists.",
  
  'cough': "Coughs can be caused by various factors including viral infections, allergies, or irritants. A persistent cough lasting more than 3 weeks should be evaluated by a healthcare provider. Stay hydrated and consider using a humidifier.",
  
  'stomach pain': "Abdominal pain can range from mild digestive issues to more serious conditions. Location, severity, and accompanying symptoms matter. Seek medical attention for severe, persistent, or worsening pain, especially with fever or vomiting.",
  
  'fatigue': "Persistent fatigue can result from various factors including sleep issues, stress, nutrition, or underlying health conditions. If fatigue significantly impacts your daily life or lasts more than a few weeks, consider discussing with a healthcare provider.",
  
  'stress': "Chronic stress can impact both mental and physical health. Consider stress management techniques like deep breathing, regular exercise, adequate sleep, and mindfulness. Professional counseling can also be very helpful for managing stress.",
  
  'diet': "A balanced diet should include a variety of fruits, vegetables, whole grains, lean proteins, and healthy fats. Stay hydrated and limit processed foods. For personalized dietary advice, consider consulting with a registered dietitian.",
  
  'exercise': "Regular physical activity is crucial for overall health. Aim for at least 150 minutes of moderate-intensity exercise per week, along with strength training twice weekly. Start slowly and gradually increase intensity. Consult your doctor before starting a new exercise program.",
  
  'sleep': "Quality sleep is essential for health. Adults typically need 7-9 hours per night. Maintain a consistent sleep schedule, create a relaxing bedtime routine, and ensure your sleep environment is cool, dark, and quiet."
};

export const simulateAIResponse = async (userMessage: string): Promise<string> => {
  // Simulate AI processing delay
  await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
  
  const message = userMessage.toLowerCase();
  
  // Check for emergency keywords
  const emergencyKeywords = ['emergency', 'urgent', 'severe pain', 'can\'t breathe', 'chest pain', 'unconscious'];
  if (emergencyKeywords.some(keyword => message.includes(keyword))) {
    return healthResponses.emergency[Math.floor(Math.random() * healthResponses.emergency.length)] + 
      "\n\n🚨 **EMERGENCY: Call 911 immediately if this is a life-threatening situation!**";
  }
  
  // Check for specific health topics
  for (const [keyword, response] of Object.entries(keywordResponses)) {
    if (message.includes(keyword)) {
      return response;
    }
  }
  
  // Check for symptom-related queries
  const symptomKeywords = ['symptom', 'pain', 'hurt', 'ache', 'feel', 'sick', 'ill'];
  if (symptomKeywords.some(keyword => message.includes(keyword))) {
    return healthResponses.symptoms[Math.floor(Math.random() * healthResponses.symptoms.length)];
  }
  
  // General health response
  return healthResponses.general[Math.floor(Math.random() * healthResponses.general.length)] + 
    " What specific aspect of health would you like to know more about?";
};