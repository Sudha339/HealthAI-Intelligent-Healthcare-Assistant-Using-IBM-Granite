import { User } from '../contexts/UserContext';

type TreatmentPlan = {
  condition: string;
  homeRemedies: string[];
  medications: string[];
  lifestyle: string[];
  timeline: string;
  warnings: string[];
};

const treatmentDatabase: Record<string, {
  homeRemedies: string[];
  medications: string[];
  lifestyle: string[];
  timeline: string;
  warnings: string[];
}> = {
  'Common Cold': {
    homeRemedies: [
      'Drink plenty of warm fluids like herbal tea, warm water with honey and lemon',
      'Use a humidifier or breathe steam from a hot shower',
      'Gargle with warm salt water (1/2 teaspoon salt in 8 oz water)',
      'Get adequate rest and sleep to support immune system recovery'
    ],
    medications: [
      'Acetaminophen or ibuprofen for aches and pains (follow package directions)',
      'Decongestant nasal sprays for short-term relief (max 3 days)',
      'Throat lozenges or cough drops for sore throat',
      'Zinc supplements may help reduce duration if taken within 24 hours'
    ],
    lifestyle: [
      'Maintain good hygiene - wash hands frequently',
      'Avoid close contact with others to prevent spreading',
      'Stay hydrated with 8-10 glasses of fluid daily',
      'Eat nutritious foods rich in vitamin C and antioxidants'
    ],
    timeline: 'Symptoms typically improve within 7-10 days. Most people feel better after 3-4 days.',
    warnings: [
      'See a healthcare provider if symptoms worsen after 3 days',
      'Seek medical attention for high fever (over 101.3°F/38.5°C)',
      'Contact doctor if you have difficulty breathing or chest pain'
    ]
  },
  'Flu': {
    homeRemedies: [
      'Rest in bed and sleep as much as possible',
      'Drink warm broths, herbal teas, and clear fluids',
      'Use a cool-mist humidifier to ease congestion',
      'Apply warm compresses to forehead and nose for sinus pressure'
    ],
    medications: [
      'Antiviral medications if prescribed within 48 hours of symptom onset',
      'Acetaminophen or ibuprofen for fever and body aches',
      'Cough suppressants for dry cough or expectorants for productive cough',
      'Electrolyte replacement drinks if experiencing vomiting or diarrhea'
    ],
    lifestyle: [
      'Stay home and avoid work/school until fever-free for 24 hours',
      'Maintain strict hygiene to prevent spreading to others',
      'Eat light, nutritious meals when appetite returns',
      'Gradually return to normal activities as energy improves'
    ],
    timeline: 'Flu symptoms typically last 1-2 weeks. Fever usually resolves within 3-4 days.',
    warnings: [
      'Seek immediate care for difficulty breathing or chest pain',
      'Contact healthcare provider if fever exceeds 103°F (39.4°C)',
      'Get medical attention for signs of dehydration'
    ]
  },
  'Headache': {
    homeRemedies: [
      'Apply cold compress to forehead or warm compress to neck and shoulders',
      'Practice relaxation techniques like deep breathing or meditation',
      'Massage temples, scalp, neck, and shoulders gently',
      'Stay in a quiet, dark room and try to rest or sleep'
    ],
    medications: [
      'Over-the-counter pain relievers: acetaminophen, ibuprofen, or aspirin',
      'Avoid overuse of pain medications (no more than 2-3 times per week)',
      'Consider caffeine in moderation, as it can sometimes help with headaches',
      'Topical pain relief creams for neck and shoulder tension'
    ],
    lifestyle: [
      'Maintain regular sleep schedule (7-9 hours per night)',
      'Stay hydrated - drink water throughout the day',
      'Manage stress through exercise, yoga, or other relaxation activities',
      'Identify and avoid personal headache triggers'
    ],
    timeline: 'Most tension headaches resolve within a few hours to a day with treatment.',
    warnings: [
      'Seek medical attention for sudden, severe headaches',
      'Contact healthcare provider for headaches with fever, stiff neck, or confusion',
      'See a doctor if headaches become more frequent or severe'
    ]
  },
  'Sore Throat': {
    homeRemedies: [
      'Gargle with warm salt water several times daily',
      'Drink warm liquids like tea with honey, warm broth, or warm water',
      'Suck on throat lozenges or hard candies to keep throat moist',
      'Use a humidifier or breathe steam from hot shower'
    ],
    medications: [
      'Over-the-counter pain relievers for throat pain and inflammation',
      'Throat sprays with numbing agents for temporary relief',
      'Antiseptic throat lozenges to reduce bacteria',
      'Anti-inflammatory medications like ibuprofen to reduce swelling'
    ],
    lifestyle: [
      'Rest your voice and avoid shouting or whispering',
      'Avoid irritants like smoke, strong scents, or dry air',
      'Stay hydrated with plenty of fluids',
      'Eat soft, soothing foods like soups, smoothies, or ice cream'
    ],
    timeline: 'Viral sore throats typically improve within 3-7 days.',
    warnings: [
      'See a healthcare provider if sore throat lasts more than a week',
      'Seek medical attention for severe difficulty swallowing',
      'Contact doctor if you have high fever with sore throat'
    ]
  },
  'Stomachache': {
    homeRemedies: [
      'Apply heat pad or warm compress to abdomen',
      'Drink clear fluids like water, clear broth, or herbal tea',
      'Try the BRAT diet: bananas, rice, applesauce, and toast',
      'Ginger tea or ginger supplements may help reduce nausea'
    ],
    medications: [
      'Anti-diarrheal medications if experiencing loose stools',
      'Antacids for heartburn or acid-related stomach pain',
      'Simethicone (Gas-X) for gas-related discomfort',
      'Probiotics to support digestive health'
    ],
    lifestyle: [
      'Eat small, frequent meals instead of large meals',
      'Avoid fatty, spicy, or highly processed foods',
      'Stay hydrated, especially if experiencing vomiting or diarrhea',
      'Rest and avoid strenuous activities until feeling better'
    ],
    timeline: 'Most stomach issues resolve within 24-48 hours with proper care.',
    warnings: [
      'Seek medical attention for severe abdominal pain',
      'Contact healthcare provider for persistent vomiting or signs of dehydration',
      'See a doctor if symptoms worsen or don\'t improve within 2-3 days'
    ]
  }
};

export const generateTreatmentPlan = async (condition: string, user: User | null): Promise<TreatmentPlan> => {
  // Simulate AI processing
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  const baseTemplate = treatmentDatabase[condition];
  if (!baseTemplate) {
    // Generic treatment plan for unknown conditions
    return {
      condition,
      homeRemedies: [
        'Get adequate rest and sleep',
        'Stay well hydrated with water and clear fluids',
        'Eat nutritious, easily digestible foods',
        'Practice stress reduction techniques'
      ],
      medications: [
        'Consult with a healthcare provider for appropriate medications',
        'Over-the-counter pain relievers may help if experiencing discomfort',
        'Follow medication instructions carefully',
        'Keep a record of any medications taken'
      ],
      lifestyle: [
        'Maintain good hygiene practices',
        'Monitor symptoms and track any changes',
        'Avoid known triggers or irritants',
        'Gradually return to normal activities as you feel better'
      ],
      timeline: 'Recovery time varies depending on the specific condition. Monitor symptoms closely.',
      warnings: [
        'Consult healthcare provider if symptoms persist or worsen',
        'Seek immediate medical attention for severe symptoms',
        'This is general information only - not a substitute for professional medical advice'
      ]
    };
  }
  
  // Personalize based on user profile
  let personalizedPlan = { ...baseTemplate, condition };
  
  if (user) {
    // Add age-specific recommendations
    if (user.age > 65) {
      personalizedPlan.warnings.unshift('Older adults should consult healthcare providers sooner for symptoms');
    }
    
    // Add allergy warnings
    if (user.allergies.length > 0) {
      personalizedPlan.warnings.push(`Avoid medications you're allergic to: ${user.allergies.join(', ')}`);
    }
    
    // Add condition-specific warnings
    if (user.conditions.includes('Diabetes')) {
      personalizedPlan.warnings.push('Monitor blood sugar levels, especially if appetite is affected');
    }
    
    if (user.conditions.includes('High Blood Pressure')) {
      personalizedPlan.warnings.push('Be cautious with decongestants and NSAIDs - consult your doctor');
    }
    
    // Adjust recommendations based on current medications
    if (user.medications.length > 0) {
      personalizedPlan.warnings.push('Check with pharmacist or doctor about interactions with current medications');
    }
  }
  
  return personalizedPlan;
};